--[[
  TouchHUD settings window, layouts and export / import
]]

local TH = TouchHUD

local function Print(m) TH.Print(m) end
local function Size(f, w, h) f:SetWidth(w); f:SetHeight(h) end
local function DB() return TH.db end

local wid = 0
local function WName() wid = wid + 1; return "TouchHUDCfgW" .. wid end

local DIRS = { { "LEFT", "Left" }, { "RIGHT", "Right" }, { "UP", "Up" }, { "DOWN", "Down" } }
local FORM_CLASSES = { WARRIOR = true, DRUID = true, ROGUE = true, PRIEST = true }

------------------------------------------------------------------------
-- Export / import  (serialize -> base64 -> "THUD2:<data>:<checksum>")
------------------------------------------------------------------------

local function Ser(v, out)
  local t = type(v)
  if t == "table" then
    out[#out + 1] = "T"
    for k, val in pairs(v) do
      local kt, vt = type(k), type(val)
      if (kt == "string" or kt == "number") and
         (vt == "table" or vt == "string" or vt == "number" or vt == "boolean") then
        Ser(k, out)
        Ser(val, out)
      end
    end
    out[#out + 1] = "E"
  elseif t == "string" then
    out[#out + 1] = "S" .. #v .. ":" .. v
  elseif t == "number" then
    out[#out + 1] = "N" .. tostring(v) .. ";"
  elseif t == "boolean" then
    out[#out + 1] = v and "B1" or "B0"
  end
end

local function Des(s)
  local pos, depth = 1, 0
  local function val()
    local c = s:sub(pos, pos)
    if c == "T" then
      depth = depth + 1
      if depth > 20 then error("too deep") end
      pos = pos + 1
      local tbl = {}
      while true do
        if pos > #s then error("truncated") end
        if s:sub(pos, pos) == "E" then pos = pos + 1 break end
        local k = val()
        local v = val()
        tbl[k] = v
      end
      depth = depth - 1
      return tbl
    elseif c == "S" then
      local colon = s:find(":", pos, true)
      if not colon then error("bad string") end
      local len = tonumber(s:sub(pos + 1, colon - 1))
      if not len then error("bad string") end
      local str = s:sub(colon + 1, colon + len)
      if #str ~= len then error("truncated") end
      pos = colon + len + 1
      return str
    elseif c == "N" then
      local semi = s:find(";", pos, true)
      if not semi then error("bad number") end
      local n = tonumber(s:sub(pos + 1, semi - 1))
      if not n then error("bad number") end
      pos = semi + 1
      return n
    elseif c == "B" then
      local b = s:sub(pos + 1, pos + 1)
      pos = pos + 2
      return b == "1"
    end
    error("bad data")
  end
  local ok, res = pcall(val)
  if ok and type(res) == "table" and pos == #s + 1 then return res end
  return nil
end

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64DEC = {}
for i = 1, 64 do B64DEC[B64:sub(i, i)] = i - 1 end

local function Enc(s)
  local out = {}
  for i = 1, #s, 3 do
    local a, b, c = s:byte(i, i + 2)
    local n = a * 65536 + (b or 0) * 256 + (c or 0)
    local c1 = math.floor(n / 262144) % 64
    local c2 = math.floor(n / 4096) % 64
    local c3 = math.floor(n / 64) % 64
    local c4 = n % 64
    out[#out + 1] = B64:sub(c1 + 1, c1 + 1) .. B64:sub(c2 + 1, c2 + 1)
                 .. (b and B64:sub(c3 + 1, c3 + 1) or "=")
                 .. (c and B64:sub(c4 + 1, c4 + 1) or "=")
  end
  return table.concat(out)
end

local function Dec(s)
  if #s % 4 ~= 0 then return nil end
  local out = {}
  for i = 1, #s, 4 do
    local c1, c2, c3, c4 = s:sub(i, i), s:sub(i + 1, i + 1), s:sub(i + 2, i + 2), s:sub(i + 3, i + 3)
    local v1, v2 = B64DEC[c1], B64DEC[c2]
    local v3 = (c3 == "=") and 0 or B64DEC[c3]
    local v4 = (c4 == "=") and 0 or B64DEC[c4]
    if not (v1 and v2 and v3 and v4) then return nil end
    local n = v1 * 262144 + v2 * 4096 + v3 * 64 + v4
    out[#out + 1] = string.char(math.floor(n / 65536))
    if c3 ~= "=" then out[#out + 1] = string.char(math.floor(n / 256) % 256) end
    if c4 ~= "=" then out[#out + 1] = string.char(n % 256) end
  end
  return table.concat(out)
end

local function Checksum(s)
  local sum = 0
  for i = 1, #s do sum = (sum * 31 + s:byte(i)) % 16777213 end
  return sum
end

function TH.ExportString()
  local out = {}
  Ser(DB(), out)
  local raw = table.concat(out)
  local str = "THUD2:" .. Enc(raw) .. ":" .. Checksum(raw)
  local lines = {}
  for i = 1, #str, 60 do lines[#lines + 1] = str:sub(i, i + 59) end
  return table.concat(lines, "\n")
end

function TH.ParseImport(text)
  text = (text or ""):gsub("%s", "")
  local body, sum = text:match("^THUD2:([%w%+/=]+):(%d+)$")
  if not body then return nil, "that is not a TouchHUD layout string." end
  local raw = Dec(body)
  if not raw or Checksum(raw) ~= tonumber(sum) then return nil, "the string is damaged or incomplete." end
  local t = Des(raw)
  if not t then return nil, "the string is damaged." end
  return t
end

------------------------------------------------------------------------
-- Popups
------------------------------------------------------------------------

StaticPopupDialogs["TOUCHHUD_RELOAD"] = {
  text = "TouchHUD: this change needs a UI reload.\nReload now?",
  button1 = "Reload", button2 = "Later",
  OnAccept = function() ReloadUI() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["TOUCHHUD_IMPORT"] = {
  text = "Import this layout into \"%s\"?\nIts current settings are replaced and the UI reloads.",
  button1 = "Import", button2 = "Cancel",
  OnAccept = function()
    if TH.pendingImport then
      local t = TH.PrepareDB(TH.pendingImport)
      TH.pendingImport = nil
      TH.ReplaceCurrentProfile(t)
    end
  end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["TOUCHHUD_RESET"] = {
  text = "Reset layout \"%s\" to default?\nThe UI reloads.",
  button1 = "Reset", button2 = "Cancel",
  OnAccept = function()
    TouchHUDDB.profiles[TouchHUDDB.current] = nil
    ReloadUI()
  end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["TOUCHHUD_SWITCH"] = {
  text = "Switch to layout \"%s\"?\nThe UI reloads.",
  button1 = "Switch", button2 = "Cancel",
  OnAccept = function() if TH.pendingSwitch then TH.SwitchProfile(TH.pendingSwitch) end end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["TOUCHHUD_LEGACY"] = {
  text = "Move this character's flyout spells from their old slots to the new fixed slots?\n\n"
      .. "Nothing is deleted: anything already in the new slots is swapped into the old ones.\n"
      .. "Do this only once per character (not again on another device).",
  button1 = "Move", button2 = "Cancel",
  OnAccept = function() TH.MoveLegacySpells() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}
StaticPopupDialogs["TOUCHHUD_DELETE"] = {
  text = "Delete layout \"%s\"?\nThe UI reloads with another layout.",
  button1 = "Delete", button2 = "Cancel",
  OnAccept = function() TH.DeleteCurrentProfile() end,
  timeout = 0, whileDead = 1, hideOnEscape = 1,
}

------------------------------------------------------------------------
-- Widgets
------------------------------------------------------------------------

local cfg
local pages, tabs = {}, {}
local sel = 1   -- flyout being edited

local function CanChange()
  if InCombatLockdown() then Print("leave combat to change settings.") return false end
  return true
end

local function Reg(page, w) page.widgets[#page.widgets + 1] = w; return w end
local function RefreshPage(p) for _, w in ipairs(p.widgets) do w.Refresh() end end
local function RefreshAll()
  for _, p in ipairs(pages) do
    if p:IsShown() then RefreshPage(p) end
  end
end
local function Changed() TH.ApplyAll(); RefreshAll() end
local function NeedReload() StaticPopup_Show("TOUCHHUD_RELOAD") end

local function Text(page, text, x, y, font, width)
  local fs = page:CreateFontString(nil, "ARTWORK", font or "GameFontHighlightSmall")
  fs:SetPoint("TOPLEFT", x, y)
  fs:SetJustifyH("LEFT")
  fs:SetJustifyV("TOP")
  if width then fs:SetWidth(width) end
  fs:SetText(text)
  return fs
end

local function Header(page, text, x, y) return Text(page, text, x, y, "GameFontNormal") end

local function Button(page, text, x, y, w, onClick)
  local b = CreateFrame("Button", WName(), page, "UIPanelButtonTemplate")
  Size(b, w or 120, 28)
  b:SetPoint("TOPLEFT", x, y)
  b:SetText(text)
  b:SetScript("OnClick", onClick)
  return b
end

local function Check(page, text, x, y, get, set)
  local name = WName()
  local c = CreateFrame("CheckButton", name, page, "UICheckButtonTemplate")
  Size(c, 30, 30)
  c:SetPoint("TOPLEFT", x, y)
  local fs = _G[name .. "Text"]
  if not fs then
    fs = c:CreateFontString(nil, "ARTWORK")
    fs:SetPoint("LEFT", c, "RIGHT", 2, 0)
  end
  fs:SetFontObject(GameFontHighlight)
  fs:SetText(text)
  c:SetScript("OnClick", function(self)
    if not CanChange() then self:SetChecked(get() and true or false) return end
    set(self:GetChecked() and true or false)
    Changed()
  end)
  c.Refresh = function() c:SetChecked(get() and true or false) end
  return Reg(page, c)
end

local function Slider(page, text, x, y, minv, maxv, step, get, set, fmt)
  local name = WName()
  local s = CreateFrame("Slider", name, page, "OptionsSliderTemplate")
  Size(s, 170, 17)
  s:SetPoint("TOPLEFT", x + 32, y - 16)
  s:SetMinMaxValues(minv, maxv)
  s:SetValueStep(step)
  _G[name .. "Low"]:SetText("")
  _G[name .. "High"]:SetText("")
  local label = _G[name .. "Text"]

  local function round(v)
    v = math.floor(v / step + 0.5) * step
    if v < minv then v = minv elseif v > maxv then v = maxv end
    return v
  end
  local function show(v) label:SetText(text .. ":  " .. (fmt and fmt(v) or tostring(v))) end

  s:SetScript("OnValueChanged", function(self, v)
    v = round(v)
    show(v)
    if self.updating then return end
    if math.abs(v - (get() or 0)) < step / 2 then return end
    if not CanChange() then self.Refresh() return end
    set(v)
    Changed()
  end)

  local minus = CreateFrame("Button", WName(), page, "UIPanelButtonTemplate")
  Size(minus, 26, 24)
  minus:SetText("-")
  minus:SetPoint("RIGHT", s, "LEFT", -4, 0)
  minus:SetScript("OnClick", function() s:SetValue(round((get() or minv) - step)) end)

  local plus = CreateFrame("Button", WName(), page, "UIPanelButtonTemplate")
  Size(plus, 26, 24)
  plus:SetText("+")
  plus:SetPoint("LEFT", s, "RIGHT", 4, 0)
  plus:SetScript("OnClick", function() s:SetValue(round((get() or minv) + step)) end)

  s.Refresh = function()
    s.updating = true
    s:SetValue(round(get() or minv))
    s.updating = false
    show(round(get() or minv))
  end
  return Reg(page, s)
end

local function Cycle(page, text, x, y, options, get, set, width, labelWidth)
  Text(page, text, x, y - 7, "GameFontHighlight")
  local b = CreateFrame("Button", WName(), page, "UIPanelButtonTemplate")
  Size(b, width or 120, 28)
  b:SetPoint("TOPLEFT", x + (labelWidth or 160), y)
  local function idx()
    local cur = get()
    for i, o in ipairs(options) do
      if o[1] == cur then return i end
    end
    return 1
  end
  b:SetScript("OnClick", function()
    if not CanChange() then return end
    set(options[idx() % #options + 1][1])
    Changed()
  end)
  b.Refresh = function() b:SetText(options[idx()][2]) end
  return Reg(page, b)
end

-- text = nil -> box only, at x
local function Input(page, text, x, y, w, get, set, maxLetters)
  local bx = x
  if text then
    Text(page, text, x, y - 6, "GameFontHighlight")
    bx = x + 166
  end
  local e = CreateFrame("EditBox", WName(), page, "InputBoxTemplate")
  Size(e, w, 26)
  e:SetPoint("TOPLEFT", bx + 6, y)
  e:SetAutoFocus(false)
  e:SetMaxLetters(maxLetters or 12)
  e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  e:SetScript("OnEditFocusGained", function(self) self.focused = true end)
  e:SetScript("OnEditFocusLost", function(self)
    self.focused = false
    set(self:GetText() or "")
    Changed()
  end)
  e.Refresh = function() if not e.focused then e:SetText(get() or "") end end
  return Reg(page, e)
end

local function Custom(page, fn) return Reg(page, { Refresh = fn }) end

local function Fmt2(v) return string.format("%.2f", v) end

local function SizeSlider(p, text, key, x, y)
  return Slider(p, text, x, y, 0.5, 3, 0.05,
    function() return DB().scale[key] end,
    function(v) DB().scale[key] = v end, Fmt2)
end

------------------------------------------------------------------------
-- Slot conflict helpers
------------------------------------------------------------------------

-- "Bottom Right bar 1-8" / "Bottom Right bar 9-12 + Right Bar 2 1-4"
local function DescribeSlots(slots)
  local parts, i = {}, 1
  while i <= #slots do
    local page = math.floor((slots[i] - 1) / 12) + 1
    local first = (slots[i] - 1) % 12 + 1
    local j = i
    while j < #slots and slots[j + 1] == slots[j] + 1 and math.floor((slots[j + 1] - 1) / 12) + 1 == page do
      j = j + 1
    end
    local last = (slots[j] - 1) % 12 + 1
    local name = TH.PAGE_NAME[page] or ("page " .. page)
    parts[#parts + 1] = name .. " " .. (first == last and first or (first .. "-" .. last))
    i = j + 1
  end
  return table.concat(parts, " + ")
end

local function SlotInfo(i)
  local f = DB().flyouts[i]
  if f.source == "stance" then
    local n = GetNumShapeshiftForms() or 0
    if n == 0 then
      return "|cffff5555This character has no stances, forms, auras or presences, so this flyout stays hidden.|r"
    end
    return "|cff33ff33Shows your " .. n .. " stances / forms / auras / presences (they use no action slots). "
        .. "Blizzard's own stance bar is hidden while this is on.|r"
  end
  local all, used = TH.FlyoutSlots(i), {}
  for j = 1, f.count do used[j] = all[j] end
  local txt = "|cff33ff33Buttons 1-" .. f.count .. " = " .. DescribeSlots(used) .. "|r"
  if f.count < 8 then
    local rest = {}
    for j = f.count + 1, 8 do rest[#rest + 1] = all[j] end
    txt = txt .. "\n|cff999999Reserved, unused: " .. DescribeSlots(rest) .. "|r"
  end
  return txt
end

local function ExtraInfo()
  local x = DB().extra
  local n = x.count
  return "Buttons X1-X" .. n .. " = Bottom Left bar 1-" .. n .. " (action slots 61-" .. (60 + n) .. "). "
      .. "Bind keys or mouse buttons in Esc > Key Bindings > Bottom Left Action Button 1-" .. n .. "."
end

------------------------------------------------------------------------
-- Pages
------------------------------------------------------------------------

local function BuildGeneral(p)
  Header(p, "Mode", 0, 0)
  Button(p, "Move", 0, -18, 110, function()
    if not CanChange() then return end
    TH.SetMode("move"); cfg:Hide()
  end)
  Button(p, "Edit spells", 116, -18, 120, function()
    if not CanChange() then return end
    TH.SetMode("edit"); cfg:Hide()
  end)
  Button(p, "Lock", 242, -18, 90, function()
    if not CanChange() then return end
    TH.SetMode("lock"); RefreshAll()
  end)
  local status = Text(p, "", 345, -26, "GameFontHighlight")
  Custom(p, function()
    status:SetText("Now: |cffffd100" .. string.upper(TH.mode or "lock") .. "|r   Layout: |cffffd100"
      .. (TH.CurrentProfile() or "") .. "|r")
  end)
  Text(p, "Move: drag green boxes (whole groups) or blue boxes (single buttons).  Edit: drag spells onto buttons.  Tap DONE to finish.",
       0, -52, nil, 580)

  Header(p, "Snapping (Move mode)", 0, -84)
  Cycle(p, "When you drop a button", 0, -104,
    { { "both", "Grid + buttons" }, { "grid", "Grid" }, { "buttons", "Line up with buttons" }, { "off", "Off" } },
    function() return DB().snap end,
    function(v) DB().snap = v end, 170)
  Check(p, "Show grid while moving", 0, -140,
    function() return DB().showGrid end,
    function(v) DB().showGrid = v end)
  Slider(p, "Grid size", 300, -138, 4, 64, 2,
    function() return DB().gridSize end,
    function(v) DB().gridSize = v end)
  Text(p, "\"Line up with buttons\" puts a dropped button in the same row or column as a nearby button. "
       .. "Groups snap to the grid only. Hold Shift while dropping to place freely.",
       0, -178, nil, 580)

  Header(p, "Bars & keys", 0, -214)
  Check(p, "Hide Blizzard main bar (reload)", 0, -234,
    function() return DB().hideMainBar end,
    function(v) DB().hideMainBar = v; NeedReload() end)
  Check(p, "One flyout open at a time", 300, -234,
    function() return DB().exclusive end,
    function(v) DB().exclusive = v end)
  Check(p, "Keys 1..= and extra-bar keys press TouchHUD buttons", 0, -264,
    function() return DB().routeBindings end,
    function(v) DB().routeBindings = v end)
  Text(p, "Hide Blizzard bars:", 0, -300, "GameFontHighlight")
  for i, b in ipairs(TH.BLIZZ_BARS) do
    Check(p, b.name, 130 + (i - 1) * 115, -292,
      function() return DB().hideBars[b.key] end,
      function(v) DB().hideBars[b.key] = v end)
  end
  Slider(p, "Settings window size", 0, -326, 0.7, 1.8, 0.05,
    function() return DB().cfgScale end,
    function(v) DB().cfgScale = v; cfg:SetScale(v) end, Fmt2)

  Button(p, "Reset button positions", 0, -372, 190, function()
    if not CanChange() then return end
    TH.ResetButtons(); RefreshAll()
  end)
  Button(p, "Reset this layout", 200, -372, 160, function()
    StaticPopup_Show("TOUCHHUD_RESET", TH.CurrentProfile())
  end)
  Button(p, "Reload UI", 370, -372, 110, function() ReloadUI() end)
end

local function BuildButtons(p)
  Header(p, "K buttons  (main bar slots 1-12, keys 1..0 - =)", 0, 0)
  for i = 1, 12 do
    local col, row = (i - 1) % 4, math.floor((i - 1) / 4)
    Check(p, "K" .. TH.KEY_NAMES[i] .. "   (key " .. TH.KEY_NAMES[i] .. ")", col * 145, -20 - row * 30,
      function() return DB().kEnabled[i] end,
      function(v) DB().kEnabled[i] = v end)
  end
  Slider(p, "Arc spacing", 0, -114, 0.5, 2, 0.05,
    function() return DB().spread end, function(v) DB().spread = v end, Fmt2)
  SizeSlider(p, "K button size", "k", 300, -114)

  Header(p, "Menu button", 0, -170)
  Check(p, "Show menu button", 0, -190,
    function() return DB().menu.enabled end,
    function(v) DB().menu.enabled = v end)
  Cycle(p, "Drawer opens towards", 260, -190, DIRS,
    function() return DB().menu.dir end,
    function(v) DB().menu.dir = v end, 100)
  SizeSlider(p, "Menu size", "menu", 0, -226)

  Header(p, "ESC / ENTER pads", 0, -280)
  Check(p, "Show ESC / ENTER", 0, -300,
    function() return DB().keys.enabled end,
    function(v) DB().keys.enabled = v end)
  SizeSlider(p, "Pad size", "keys", 300, -298)

  Text(p, "Hidden buttons keep their spells and their keys still work. New K buttons start next to K1/K2. Place them with General > Move.",
       0, -346, nil, 580)
end

local function BuildFlyouts(p)
  local function F() return DB().flyouts[sel] end

  for i = 1, 5 do
    local b = CreateFrame("Button", WName(), p, "UIPanelButtonTemplate")
    Size(b, 112, 28)
    b:SetPoint("TOPLEFT", (i - 1) * 117, 0)
    b:SetScript("OnClick", function() sel = i; RefreshPage(p) end)
    b.Refresh = function()
      local f = DB().flyouts[i]
      local name = (f.label ~= "" and f.label) or ("Flyout " .. i)
      b:SetText((f.enabled and "" or "|cff888888") .. i .. ". " .. name)
      if i == sel then b:LockHighlight() else b:UnlockHighlight() end
    end
    Reg(p, b)
  end

  Check(p, "Enabled", 0, -38,
    function() return F().enabled end,
    function(v) F().enabled = v end)
  Check(p, "Always open", 150, -38,
    function() return F().alwaysOpen end,
    function(v) F().alwaysOpen = v end)
  Check(p, "Hide its button when always open", 300, -38,
    function() return F().hideExpander end,
    function(v) F().hideExpander = v end)
  local count = Slider(p, "Buttons", 0, -74, 2, 8, 1,
    function() return F().count end,
    function(v) F().count = v end)
  Custom(p, function() count:SetAlpha(F().source == "stance" and 0.35 or 1) end)
  local info = Text(p, "", 0, -116, "GameFontHighlight", 580)
  Custom(p, function() info:SetText(SlotInfo(sel)) end)
  Cycle(p, "Opens towards", 0, -156, DIRS,
    function() return F().dir end,
    function(v) F().dir = v end, 100)
  Input(p, "Label", 0, -192, 120,
    function() return F().label end,
    function(v) F().label = v end)
  SizeSlider(p, "Flyout size (all)", "exp", 300, -188)

  -- one-time move of spells from 2.0/2.1 flyout slots (per character)
  local legacyText = Text(p, "", 0, -236, "GameFontHighlight", 580)
  local moveBtn = Button(p, "Move my old flyout spells", 0, -268, 230, function()
    if not CanChange() then return end
    StaticPopup_Show("TOUCHHUD_LEGACY")
  end)
  local skipBtn = Button(p, "Not needed", 240, -268, 120, function()
    TH.SkipLegacy(); RefreshAll()
  end)
  Custom(p, function()
    local pending = TH.LegacyPending()
    if pending then
      legacyText:SetText("|cffffd100Your flyouts now have fixed slots. This character still has spells in the old ones ("
        .. TH.LegacyText() .. "). Do this once per character, on one device only.|r")
      moveBtn:Show(); skipBtn:Show()
    else
      legacyText:SetText("")
      moveBtn:Hide(); skipBtn:Hide()
    end
  end)

  Text(p, "Each flyout has 8 fixed slots in order: flyout 1 = Bottom Right 1-8, flyout 2 = Bottom Right 9-12 + Right Bar 2 1-4, "
       .. "flyout 3 = Right Bar 2 5-12, flyout 4 = Right Bar 1-8. Fewer buttons leave the rest unused, so nothing ever shifts. "
       .. "Flyout 5 is your stance / form / aura bar. Always open: the row stays out (its button can be hidden; it reappears in Move mode).",
       0, -306, nil, 580)
end

local function BuildExtra(p)
  local function X() return DB().extra end
  Check(p, "Show extra bar", 0, 0,
    function() return X().enabled end,
    function(v) X().enabled = v end)
  Slider(p, "Buttons", 0, -38, 1, 12, 1,
    function() return X().count end,
    function(v) X().count = v end)
  SizeSlider(p, "Extra bar size", "extra", 300, -38)
  Cycle(p, "Layout", 0, -84,
    { { "HORIZONTAL", "Row" }, { "VERTICAL", "Column" } },
    function() return X().row end,
    function(v) X().row = v; DB().xpos = {} end, 100)
  local info = Text(p, "", 0, -118, "GameFontHighlight", 580)
  Custom(p, function() info:SetText(ExtraInfo()) end)

  Header(p, "Buttons  (tick to show, type a short label)", 0, -176)
  for i = 1, 12 do
    local col, row = math.floor((i - 1) / 6), (i - 1) % 6
    local x, y = col * 300, -196 - row * 34
    local c = Check(p, "X" .. i, x, y,
      function() return X().xEnabled[i] ~= false end,
      function(v) X().xEnabled[i] = v end)
    local e = Input(p, nil, x + 64, y - 2, 110,
      function() return X().labels[i] or "" end,
      function(v) X().labels[i] = (v ~= "" and v) or nil end, 10)
    Custom(p, function()
      local a = (i <= X().count) and 1 or 0.35
      c:SetAlpha(a); e:SetAlpha(a)
    end)
  end
end

local function BuildClass(p)
  Header(p, "Pet bar", 0, 0)
  Check(p, "Use TouchHUD pet bar (reload)", 0, -20,
    function() return DB().pet.enabled end,
    function(v) DB().pet.enabled = v; NeedReload() end)
  Slider(p, "Columns", 0, -56, 1, 10, 1,
    function() return DB().pet.cols end,
    function(v) DB().pet.cols = v end)
  SizeSlider(p, "Pet bar size", "pet", 300, -56)

  Header(p, "Shaman totems", 0, -110)
  local note = Text(p, "", 120, -111, "GameFontHighlightSmall")
  Custom(p, function()
    note:SetText(TH.playerClass == "SHAMAN" and "" or "|cffff5555(only active on Shamans)|r")
  end)
  Check(p, "Use TouchHUD totem bar (reload)", 0, -130,
    function() return DB().totem.enabled end,
    function(v) DB().totem.enabled = v; NeedReload() end)
  SizeSlider(p, "Totem size", "totem", 300, -128)
  Cycle(p, "Call buttons in a", 0, -168,
    { { "HORIZONTAL", "Row" }, { "VERTICAL", "Column" } },
    function() return DB().totem.row end,
    function(v) DB().totem.row = v end, 100)
  Cycle(p, "Totem slots open", 0, -202, DIRS,
    function() return DB().totem.dir end,
    function(v) DB().totem.dir = v end, 100)
  Cycle(p, "Totem list opens", 0, -236, DIRS,
    function() return DB().totem.chooserDir end,
    function(v) DB().totem.chooserDir = v end, 100)
  Text(p, "Tap a Call to cast it, its +/- tab to open its 4 totem slots, and a slot to choose its totem (out of combat). "
       .. "With a Row, open slots Up or Down. With a Column, open them Left or Right.",
       0, -274, nil, 580)

  Header(p, "Stances / forms / auras / presences", 0, -324)
  Text(p, "On the Flyouts tab, set a flyout's Content to \"Stances / forms / auras\" (flyout 4 by default).",
       0, -342, nil, 580)
end

local function BuildLayouts(p)
  Header(p, "Layouts on this device  (tap one to switch)", 0, 0)
  local status
  for j = 1, 8 do
    local col, row = (j - 1) % 4, math.floor((j - 1) / 4)
    local b = CreateFrame("Button", WName(), p, "UIPanelButtonTemplate")
    Size(b, 140, 28)
    b:SetPoint("TOPLEFT", col * 146, -20 - row * 32)
    b:SetScript("OnClick", function(self)
      if not self.profile or self.profile == TH.CurrentProfile() then return end
      TH.pendingSwitch = self.profile
      StaticPopup_Show("TOUCHHUD_SWITCH", self.profile)
    end)
    Custom(p, function()
      local name = TH.ProfileNames()[j]
      b.profile = name
      if name then
        b:SetText(name == TH.CurrentProfile() and ("|cffffd100" .. name .. "|r") or name)
        if name == TH.CurrentProfile() then b:LockHighlight() else b:UnlockHighlight() end
        b:Show()
      else
        b:Hide()
      end
    end)
  end

  Text(p, "Save as new layout:", 0, -96, "GameFontHighlight")
  local nameBox = CreateFrame("EditBox", WName(), p, "InputBoxTemplate")
  Size(nameBox, 140, 26)
  nameBox:SetPoint("TOPLEFT", 150, -90)
  nameBox:SetAutoFocus(false)
  nameBox:SetMaxLetters(20)
  nameBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  nameBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  Button(p, "Save copy", 300, -89, 110, function()
    if not CanChange() then return end
    local ok, err = TH.SaveAsProfile(nameBox:GetText())
    if ok then
      nameBox:SetText("")
      status:SetText("|cff33ff33Saved. You are now on \"" .. TH.CurrentProfile() .. "\".|r")
    else
      status:SetText("|cffff5555" .. err .. "|r")
    end
    RefreshAll()
  end)
  Button(p, "Delete current", 420, -89, 130, function()
    if #TH.ProfileNames() < 2 then
      status:SetText("|cffff5555You need at least one layout.|r")
      return
    end
    StaticPopup_Show("TOUCHHUD_DELETE", TH.CurrentProfile())
  end)

  Header(p, "Export / import the current layout", 0, -132)
  Text(p, "Export makes one text string from this layout (positions, sizes, flyouts, options). "
       .. "Paste it on another device and tap Import. Spells are not included, because the server stores them.",
       0, -150, nil, 580)

  local box = CreateFrame("Frame", nil, p)
  box:SetPoint("TOPLEFT", 0, -218)
  box:SetPoint("BOTTOMRIGHT", 0, 22)
  box:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
  })
  box:SetBackdropColor(0, 0, 0, 0.8)

  local sf = CreateFrame("ScrollFrame", WName(), box, "UIPanelScrollFrameTemplate")
  sf:SetPoint("TOPLEFT", 8, -8)
  sf:SetPoint("BOTTOMRIGHT", -28, 8)

  local eb = CreateFrame("EditBox", WName(), sf)
  eb:SetMultiLine(true)
  eb:SetMaxLetters(99999)
  eb:SetAutoFocus(false)
  eb:SetFontObject(ChatFontNormal)
  Size(eb, 530, 140)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  if ScrollingEdit_OnTextChanged then
    eb:SetScript("OnTextChanged", function(self) ScrollingEdit_OnTextChanged(self, sf) end)
    eb:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged)
    eb:SetScript("OnUpdate", function(self, el) ScrollingEdit_OnUpdate(self, el, sf) end)
  end
  sf:SetScrollChild(eb)
  box:EnableMouse(true)
  box:SetScript("OnMouseDown", function() eb:SetFocus() end)

  status = Text(p, "", 0, -394, "GameFontHighlight", 580)

  Button(p, "Export", 0, -184, 120, function()
    eb:SetText(TH.ExportString())
    eb:SetFocus()
    eb:HighlightText()
    status:SetText("|cff33ff33Exported. It's selected, so press Ctrl+C to copy it.|r")
  end)
  Button(p, "Import", 126, -184, 120, function()
    local t, err = TH.ParseImport(eb:GetText())
    if not t then
      status:SetText("|cffff5555Import failed: " .. err .. "|r")
      return
    end
    TH.pendingImport = t
    StaticPopup_Show("TOUCHHUD_IMPORT", TH.CurrentProfile())
  end)
  Button(p, "Select all", 252, -184, 110, function() eb:SetFocus(); eb:HighlightText() end)
  Button(p, "Clear", 368, -184, 90, function()
    eb:SetText(""); eb:SetFocus()
    status:SetText("Paste a layout string, then tap Import.")
  end)
end

------------------------------------------------------------------------
-- Window
------------------------------------------------------------------------

local TAB_NAMES = { "General", "Buttons", "Flyouts", "Extra bar", "Class bars", "Layouts" }
local BUILDERS  = { BuildGeneral, BuildButtons, BuildFlyouts, BuildExtra, BuildClass, BuildLayouts }

local function SelectTab(i)
  cfg.tab = i
  for j, p in ipairs(pages) do
    if j == i then p:Show() else p:Hide() end
    if j == i then tabs[j]:LockHighlight() else tabs[j]:UnlockHighlight() end
  end
  RefreshPage(pages[i])
end

local function Build()
  cfg = CreateFrame("Frame", "TouchHUDConfig", UIParent)
  Size(cfg, 650, 520)
  cfg:SetPoint("CENTER")
  cfg:SetFrameStrata("DIALOG")
  cfg:SetToplevel(true)
  cfg:EnableMouse(true)
  cfg:SetMovable(true)
  cfg:SetClampedToScreen(true)
  cfg:RegisterForDrag("LeftButton")
  cfg:SetScript("OnDragStart", cfg.StartMoving)
  cfg:SetScript("OnDragStop", cfg.StopMovingOrSizing)
  cfg:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  cfg:Hide()
  tinsert(UISpecialFrames, "TouchHUDConfig")

  local title = cfg:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", 0, -18)
  title:SetText("TouchHUD")

  local close = CreateFrame("Button", nil, cfg, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", -6, -6)

  for i, name in ipairs(TAB_NAMES) do
    local t = CreateFrame("Button", WName(), cfg, "UIPanelButtonTemplate")
    Size(t, 98, 30)
    t:SetPoint("TOPLEFT", 20 + (i - 1) * 102, -44)
    t:SetText(name)
    t:SetScript("OnClick", function() SelectTab(i) end)
    tabs[i] = t

    local p = CreateFrame("Frame", nil, cfg)
    p:SetPoint("TOPLEFT", 26, -88)
    p:SetPoint("BOTTOMRIGHT", -26, 18)
    p.widgets = {}
    p:Hide()
    pages[i] = p
    BUILDERS[i](p)
  end
end

function TH.OpenConfig()
  if not TH.ready or not DB() then return end
  if not cfg then Build() end
  if cfg:IsShown() then cfg:Hide() return end
  cfg:SetScale(DB().cfgScale or 1)
  cfg:Show()
  SelectTab(cfg.tab or 1)
end

------------------------------------------------------------------------
-- Entry in Interface > AddOns
------------------------------------------------------------------------

local panel = CreateFrame("Frame", "TouchHUDOptionsPanel", UIParent)
panel.name = "TouchHUD"
panel:Hide()
local pt = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
pt:SetPoint("TOPLEFT", 16, -16)
pt:SetText("TouchHUD")
local pb = CreateFrame("Button", "TouchHUDOptionsOpen", panel, "UIPanelButtonTemplate")
Size(pb, 200, 30)
pb:SetPoint("TOPLEFT", 16, -50)
pb:SetText("Open TouchHUD settings")
pb:SetScript("OnClick", function()
  if InterfaceOptionsFrame then HideUIPanel(InterfaceOptionsFrame) end
  if GameMenuFrame then HideUIPanel(GameMenuFrame) end
  TH.OpenConfig()
end)
if InterfaceOptions_AddCategory then InterfaceOptions_AddCategory(panel) end

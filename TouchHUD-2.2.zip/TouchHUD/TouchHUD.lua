--[[
  TouchHUD 2.2  -  touch- and PC-friendly HUD for World of Warcraft 3.3.5a
  (c) 2026 Radu Liceac - MIT License (see LICENSE)

  * K1..K12  : main-bar slots 1-12 (keys 1..0, -, =) with stance/form/vehicle
               paging. Each one can be shown/hidden and placed on its own.
  * Flyouts  : up to 5 expandable buttons (2-8 buttons each, action slots or
               your class bar). Can be set to stay open permanently.
  * Extra bar: up to 12 buttons on a Blizzard bar (Bottom Left by default),
               so the normal Key Bindings menu works for them (mouse buttons).
  * Totems   : (Shaman) Calls + Recall, Call -> slots -> totem list.
  * Pet bar, menu drawer, ESC / ENTER pads.
  * Move mode with grid overlay, snap-to-grid and line-up with other buttons.
  * Named layouts (e.g. "PC" and "Touch"), export / import strings.

  /thud  -> settings window      /thud move | edit | lock | help
]]

TouchHUD = TouchHUD or {}
local TH = TouchHUD

local core = CreateFrame("Frame", "TouchHUDCore")
local hider = CreateFrame("Frame", "TouchHUDHider")
hider:Hide()

local db                    -- the active layout
local frames = {}           -- group key -> group frame
TH.frames = frames

-- forward declarations
local UpdateExpIcons, UpdateExpBorders, UpdateStanceButtons
local UpdateTotemSlots, UpdateTotemCooldowns, LayoutTotems
local SetMode, ApplyAll, ApplyBindings

------------------------------------------------------------------------
-- Key binding menu entries (Esc > Key Bindings > TouchHUD)
------------------------------------------------------------------------

BINDING_HEADER_TOUCHHUD = "TouchHUD"
BINDING_NAME_TOUCHHUD_CONFIG = "Open settings"
BINDING_NAME_TOUCHHUD_MOVE = "Move mode on / off"
for i = 1, 5 do
  _G["BINDING_NAME_CLICK TouchHUDExp" .. i .. ":LeftButton"] = "Open / close flyout " .. i
end
_G["BINDING_NAME_CLICK TouchHUDMenuToggle:LeftButton"] = "Open / close menu drawer"

------------------------------------------------------------------------
-- Constants
------------------------------------------------------------------------

local NUM_K           = 12
local NUM_FLYOUTS     = 5
local MAX_FLY_ACTIONS = 8
local MAX_EXTRA       = 12
local MAX_STANCES     = 10
local SNAP_TOL        = 12
local QUESTION        = "Interface\\Icons\\INV_Misc_QuestionMark"

TH.KEY_NAMES = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=" }

-- Offsets of K1..K12 from the joystick centre.
local K_LAYOUT = {
  { -257, -94 }, { -257, -49 },   -- K1, K2
  { -176, -26 }, { -176,  19 },   -- K3, K4
  {  -94,  42 }, {  -94,  88 },   -- K5, K6
  {  -13, 110 }, {  -13, 156 },   -- K7, K8
  { -338, -94 }, { -338, -49 },   -- K9, K0
  { -419, -94 }, { -419, -49 },   -- K-, K=
}

-- Default offsets of the 5 expanders from the centre of their group.
-- (flyout 5 is the class bar; it keeps the spot flyout 4 had in 2.0/2.1)
local EXP_LAYOUT = { { 0, 50 }, { 0, 0 }, { 0, -50 }, { -56, 0 }, { -56, 50 } }

------------------------------------------------------------------------
-- Fixed slot map: every button owns one Blizzard action slot, so a PC
-- without the addon still has everything on the default bars.
--   K1-K12      -> main bar             slots  1-12
--   Extra bar   -> Bottom Left bar      slots 61-72
--   Flyouts 1-4 -> Bottom Right, Right Bar 2, Right Bar (in that order,
--                  8 each = 32 of the 36 slots; Right Bar 9-12 stay free)
--   Flyout 5    -> stances / forms / auras (no slots)
------------------------------------------------------------------------

local EXTRA_BAR = { name = "Bottom Left", page = 6, bind = "MULTIACTIONBAR1BUTTON" }
TH.EXTRA_BAR = EXTRA_BAR

local PAGE_NAME = { [1] = "Main bar", [3] = "Right Bar", [4] = "Right Bar 2",
                    [5] = "Bottom Right bar", [6] = "Bottom Left bar" }
TH.PAGE_NAME = PAGE_NAME

local SLOT_SEQUENCE = {}
for s = 49, 60 do SLOT_SEQUENCE[#SLOT_SEQUENCE + 1] = s end   -- Bottom Right 1-12
for s = 37, 48 do SLOT_SEQUENCE[#SLOT_SEQUENCE + 1] = s end   -- Right Bar 2 1-12
for s = 25, 36 do SLOT_SEQUENCE[#SLOT_SEQUENCE + 1] = s end   -- Right Bar 1-12

local NUM_ACTION_FLYOUTS = 4
local STANCE_FLYOUT = 5

local function FlyoutSlots(i)
  local t = {}
  if i > NUM_ACTION_FLYOUTS then return t end
  for j = 1, 8 do t[j] = SLOT_SEQUENCE[(i - 1) * 8 + j] end
  return t
end
TH.FlyoutSlots = FlyoutSlots

-- key binding prefix for each action page (so flyout buttons show hotkeys)
local PAGE_BIND = {
  [1] = "ACTIONBUTTON", [3] = "MULTIACTIONBAR3BUTTON", [4] = "MULTIACTIONBAR4BUTTON",
  [5] = "MULTIACTIONBAR2BUTTON", [6] = "MULTIACTIONBAR1BUTTON",
}

-- Same paging the default main bar uses.
local PAGE_DRIVER = "[bonusbar:5]11;[bar:2]2;[bar:3]3;[bar:4]4;[bar:5]5;[bar:6]6;"
                 .. "[bonusbar:1]7;[bonusbar:2]8;[bonusbar:3]9;[bonusbar:4]10;1"

local MICRO_BUTTONS = {
  "CharacterMicroButton", "SpellbookMicroButton", "TalentMicroButton",
  "AchievementMicroButton", "QuestLogMicroButton", "SocialsMicroButton",
  "PVPMicroButton", "LFDMicroButton", "MainMenuMicroButton", "HelpMicroButton",
}
local BAG_BUTTONS = {
  "MainMenuBarBackpackButton", "CharacterBag0Slot", "CharacterBag1Slot",
  "CharacterBag2Slot", "CharacterBag3Slot", "KeyRingButton",
}

-- Chained buttons: anchor point, relative point, first gap x/y, gap x/y
local FLY_DIR = {
  LEFT  = { "RIGHT",  "LEFT",   -8,  0, -4,  0 },
  RIGHT = { "LEFT",   "RIGHT",   8,  0,  4,  0 },
  UP    = { "BOTTOM", "TOP",     0,  8,  0,  4 },
  DOWN  = { "TOP",    "BOTTOM",  0, -8,  0, -4 },
}
local TAB_DIR = {
  UP    = { "BOTTOM", "TOP",     0,  2, 44, 18 },
  DOWN  = { "TOP",    "BOTTOM",  0, -2, 44, 18 },
  LEFT  = { "RIGHT",  "LEFT",   -2,  0, 18, 44 },
  RIGHT = { "LEFT",   "RIGHT",   2,  0, 18, 44 },
}
local DRAWER_DIR = {
  RIGHT = { "LEFT",   "RIGHT",  4,  0 },
  LEFT  = { "RIGHT",  "LEFT",  -4,  0 },
  DOWN  = { "TOP",    "BOTTOM", 0, -4 },
  UP    = { "BOTTOM", "TOP",    0,  4 },
}
local VALID_DIR  = { LEFT = true, RIGHT = true, UP = true, DOWN = true }
local VALID_SNAP = { off = true, grid = true, buttons = true, both = true }

local TOTEM_CALLS  = TOTEM_MULTI_CAST_SUMMON_SPELLS or { 66842, 66843, 66844 }
local TOTEM_RECALL = (TOTEM_MULTI_CAST_RECALL_SPELLS and TOTEM_MULTI_CAST_RECALL_SPELLS[1]) or 36936
local TOTEM_ORDER  = TOTEM_PRIORITIES or { 2, 1, 3, 4 }   -- Earth, Fire, Water, Air
local ELEMENT_NAME  = { [1] = "Fire", [2] = "Earth", [3] = "Water", [4] = "Air" }
local ELEMENT_COLOR = { [1] = { 1, 0.35, 0.1 }, [2] = { 0.65, 0.45, 0.2 },
                        [3] = { 0.2, 0.55, 1 }, [4] = { 0.75, 0.9, 1 } }

local DEFAULTS = {
  pos = {
    k     = { "BOTTOMRIGHT", -171, 160 },  -- joystick centre
    exp   = { "BOTTOMRIGHT", -154, 441 },
    menu  = { "TOP",         -300, -30 },
    keys  = { "BOTTOMLEFT",    50, 210 },
    pet   = { "BOTTOM",         0, 300 },
    totem = { "BOTTOMLEFT",   260, 330 },
    extra = { "BOTTOM",         0,  60 },
  },
  scale  = { k = 1.25, exp = 1.2, menu = 1.3, keys = 1.2, pet = 1.4, totem = 1.1, extra = 1.2 },
  spread = 1,
  kpos = {},   -- per-button overrides of K_LAYOUT
  epos = {},   -- per-button overrides of EXP_LAYOUT
  xpos = {},   -- per-button positions on the extra bar
  kEnabled = { true, true, true, true, true, true, true, true, false, false, false, false },
  flyouts = {
    { enabled = true,  source = "action", count = 8, dir = "LEFT", label = "Buffs",  alwaysOpen = false, hideExpander = false },
    { enabled = true,  source = "action", count = 8, dir = "LEFT", label = "Food",   alwaysOpen = false, hideExpander = false },
    { enabled = true,  source = "action", count = 8, dir = "LEFT", label = "Mounts", alwaysOpen = false, hideExpander = false },
    { enabled = false, source = "action", count = 8, dir = "LEFT", label = "More",   alwaysOpen = false, hideExpander = false },
    { enabled = true,  source = "stance", count = 8, dir = "LEFT", label = "Stance", alwaysOpen = false, hideExpander = false },
  },
  extra = {
    enabled = false, count = 12, row = "HORIZONTAL",
    xEnabled = { true, true, true, true, true, true, true, true, true, true, true, true },
    labels = {},
  },
  exclusive     = true,   -- opening one flyout closes the others
  hideMainBar   = true,   -- hide Blizzard's bottom main bar
  hideBars = {            -- hide Blizzard's extra bars (their keybinds keep working)
    bottomLeft = false, bottomRight = false, right = false, right2 = false,
  },
  routeBindings = true,   -- keys 1..= and extra-bar binds press TouchHUD buttons
  snap     = "both",      -- off | grid | buttons | both
  gridSize = 16,
  showGrid = true,
  menu  = { enabled = true, dir = "RIGHT" },
  keys  = { enabled = true },
  pet   = { enabled = true, cols = 10 },
  totem = { enabled = true, row = "HORIZONTAL", dir = "UP", chooserDir = "RIGHT" },
  cfgScale = 1.1,
}
TH.DEFAULTS = DEFAULTS

local BACKDROP = {
  bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 12,
  insets = { left = 3, right = 3, top = 3, bottom = 3 },
}
local BORDER_IDLE = { 0.55, 0.55, 0.55 }
local BORDER_OPEN = { 1, 0.82, 0 }

------------------------------------------------------------------------
-- Helpers
------------------------------------------------------------------------

local function Print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99TouchHUD|r: " .. tostring(msg))
end
TH.Print = Print

local function Size(f, w, h) f:SetWidth(w); f:SetHeight(h) end

local function CopyDefaults(src, dst)
  if type(dst) ~= "table" then dst = {} end
  for k, v in pairs(src) do
    if type(v) == "table" then
      dst[k] = CopyDefaults(v, dst[k])
    elseif dst[k] == nil then
      dst[k] = v
    end
  end
  return dst
end

local function DeepCopy(t)
  if type(t) ~= "table" then return t end
  local c = {}
  for k, v in pairs(t) do c[k] = DeepCopy(v) end
  return c
end

-- v1.x saved data -> v2 layout
local function Migrate(d)
  if type(d) ~= "table" then return d end
  if type(d.exp) == "table" and type(d.flyouts) ~= "table" then
    d.flyouts = {}
    for i = 1, 3 do
      local o = d.exp[i]
      if type(o) == "table" then
        d.flyouts[i] = { start = o.start, label = o.label, dir = d.flyDir }
      end
    end
  end
  d.exp, d.flyDir = nil, nil

  -- 2.0/2.1 (free slot ranges) -> fixed slot map. Action flyouts keep their
  -- order and become flyouts 1-4, the class-bar flyout becomes flyout 5.
  -- Their old slots are remembered in d.legacy so the spells can be moved.
  if type(d.flyouts) == "table" then
    local old = d.flyouts
    local hadStart = false
    for i = 1, 5 do
      if type(old[i]) == "table" and old[i].start ~= nil then hadStart = true end
    end
    if hadStart then
      local actions, stance = {}, nil
      for i = 1, 5 do
        local f = old[i]
        if type(f) == "table" then
          if f.source == "stance" then
            stance = stance or i
          else
            actions[#actions + 1] = i
          end
        end
      end
      local newF, newE, legacy = {}, {}, {}
      local epos = type(d.epos) == "table" and d.epos or {}
      for n = 1, NUM_ACTION_FLYOUTS do
        local oi = actions[n]
        if oi then
          local f = old[oi]
          local start, count = tonumber(f.start), tonumber(f.count) or 5
          if f.enabled ~= false and start then
            legacy[n] = {}
            for j = 1, math.min(count, 8) do legacy[n][j] = start + j - 1 end
          end
          f.start, f.source = nil, "action"
          newF[n], newE[n] = f, epos[oi]
        end
      end
      if stance then
        old[stance].start = nil
        newF[STANCE_FLYOUT], newE[STANCE_FLYOUT] = old[stance], epos[stance]
      end
      d.flyouts, d.epos, d.legacy = newF, newE, legacy
    end
  end
  return d
end

local function Clamp(v, lo, hi, def)
  v = tonumber(v)
  if not v then return def end
  if v < lo then return lo elseif v > hi then return hi end
  return v
end

local function Sanitize(d)
  for key, def in pairs(DEFAULTS.pos) do
    local p = d.pos[key]
    if type(p) ~= "table" or type(p[1]) ~= "string" or type(p[2]) ~= "number" or type(p[3]) ~= "number" then
      d.pos[key] = { def[1], def[2], def[3] }
    end
  end
  for key, def in pairs(DEFAULTS.scale) do
    d.scale[key] = Clamp(d.scale[key], 0.3, 4, def)
  end
  d.spread = Clamp(d.spread, 0.3, 3, 1)
  d.cfgScale = Clamp(d.cfgScale, 0.5, 2, 1.1)
  d.gridSize = math.floor(Clamp(d.gridSize, 4, 64, 16))
  if not VALID_SNAP[d.snap] then d.snap = "both" end
  for _, store in ipairs({ "kpos", "epos", "xpos" }) do
    for i, p in pairs(d[store]) do
      if type(p) ~= "table" or type(p[1]) ~= "number" or type(p[2]) ~= "number" then d[store][i] = nil end
    end
  end
  for i = 1, NUM_FLYOUTS do
    local f = d.flyouts[i]
    f.source = (i == STANCE_FLYOUT) and "stance" or "action"
    f.start = nil
    if not VALID_DIR[f.dir] then f.dir = "LEFT" end
    f.count = math.floor(Clamp(f.count, 2, MAX_FLY_ACTIONS, 8))
    if type(f.label) ~= "string" then f.label = "" end
  end
  if type(d.legacy) == "table" then
    for n, list in pairs(d.legacy) do
      if type(n) ~= "number" or type(list) ~= "table" then d.legacy[n] = nil end
    end
  else
    d.legacy = nil
  end
  local x = d.extra
  x.bar = nil
  x.count = math.floor(Clamp(x.count, 1, MAX_EXTRA, 12))
  if x.row ~= "VERTICAL" then x.row = "HORIZONTAL" end
  for i, v in pairs(x.labels) do
    if type(v) ~= "string" then x.labels[i] = nil end
  end
  if not VALID_DIR[d.menu.dir] then d.menu.dir = "RIGHT" end
  if not VALID_DIR[d.totem.dir] then d.totem.dir = "UP" end
  if not VALID_DIR[d.totem.chooserDir] then d.totem.chooserDir = "RIGHT" end
  if d.totem.row ~= "VERTICAL" then d.totem.row = "HORIZONTAL" end
  d.pet.cols = math.floor(Clamp(d.pet.cols, 1, 10, 10))
  return d
end

function TH.PrepareDB(t)
  return Sanitize(CopyDefaults(DEFAULTS, Migrate(t)))
end

-- Saved data: { current = "Default", profiles = { [name] = layout } }
local function PrepareRoot(root)
  if type(root) ~= "table" then root = {} end
  if type(root.profiles) ~= "table" then
    local old = root
    root = { profiles = {}, current = "Default" }
    if next(old) then root.profiles.Default = old end
  end
  if type(root.current) ~= "string" then root.current = "Default" end
  for name, p in pairs(root.profiles) do
    if type(name) ~= "string" or type(p) ~= "table" then root.profiles[name] = nil end
  end
  root.profiles[root.current] = TH.PrepareDB(root.profiles[root.current])
  return root
end

local function SetRef(owner, label, ref)
  if owner.SetFrameRef then
    owner:SetFrameRef(label, ref)
  else
    SecureHandlerSetFrameRef(owner, label, ref)
  end
end

local function StyleBox(f)
  f:SetBackdrop(BACKDROP)
  f:SetBackdropColor(0, 0, 0, 0.65)
  f:SetBackdropBorderColor(unpack(BORDER_IDLE))
end

local function SetOpen(f, open)
  f:SetBackdropBorderColor(unpack(open and BORDER_OPEN or BORDER_IDLE))
end

local function TextButton(name, parent, w, h, text)
  local b = CreateFrame("Button", name, parent)
  Size(b, w, h)
  StyleBox(b)
  b:RegisterForClicks("AnyUp")
  b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
  local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fs:SetPoint("CENTER")
  fs:SetText(text)
  b.text = fs
  return b
end

local function IconButton(name, parent, size, secure)
  local b = CreateFrame("Button", name, parent, secure and "SecureActionButtonTemplate" or nil)
  Size(b, size, size)
  StyleBox(b)
  b:RegisterForClicks("AnyUp")
  local icon = b:CreateTexture(nil, "ARTWORK")
  icon:SetPoint("TOPLEFT", 4, -4)
  icon:SetPoint("BOTTOMRIGHT", -4, 4)
  icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  b.icon = icon
  b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
  return b
end

-- slot -> page / id inside page (Blizzard bars work the same way)
local function SlotToPage(slot)
  return math.floor((slot - 1) / 12) + 1, (slot - 1) % 12 + 1
end

------------------------------------------------------------------------
-- Coordinates, snapping, grid
------------------------------------------------------------------------

local kButtons, expButtons, xButtons, flyouts = {}, {}, {}, {}

local function UIScaleOf(f) return f:GetEffectiveScale() / UIParent:GetEffectiveScale() end

local function AbsCenter(f)
  local x, y = f:GetCenter()
  if not x then return nil end
  local s = UIScaleOf(f)
  return x * s, y * s
end

local function SnapCandidates()
  local list = {}
  for _, set in ipairs({ kButtons, xButtons, expButtons }) do
    for _, b in ipairs(set) do
      if b:IsVisible() then list[#list + 1] = b end
    end
  end
  return list
end

-- x, y in UIParent units. me = frame being dropped (excluded),
-- gridOnly = groups only snap to the grid.
local function SnapPoint(x, y, me, gridOnly)
  if IsShiftKeyDown() then return x, y end
  local mode = db.snap
  if mode == "off" then return x, y end
  local sx, sy
  if not gridOnly and (mode == "buttons" or mode == "both") then
    local bestX, bestY = SNAP_TOL, SNAP_TOL
    for _, f in ipairs(SnapCandidates()) do
      if f ~= me then
        local ox, oy = AbsCenter(f)
        if ox then
          local dx, dy = math.abs(ox - x), math.abs(oy - y)
          if dx < bestX then bestX, sx = dx, ox end
          if dy < bestY then bestY, sy = dy, oy end
        end
      end
    end
  end
  if mode == "grid" or mode == "both" then
    local g = db.gridSize
    local cx, cy = UIParent:GetWidth() / 2, UIParent:GetHeight() / 2
    if not sx then sx = cx + math.floor((x - cx) / g + 0.5) * g end
    if not sy then sy = cy + math.floor((y - cy) / g + 0.5) * g end
  end
  return sx or x, sy or y
end

local grid
local function UpdateGrid()
  local show = db and TH.mode == "move" and db.showGrid
  if not show then
    if grid then grid:Hide() end
    return
  end
  if not grid then
    grid = CreateFrame("Frame", "TouchHUDGrid", UIParent)
    grid:SetAllPoints(UIParent)
    grid:SetFrameStrata("BACKGROUND")
    grid.lines = {}
  end
  local g = db.gridSize
  local W, H = UIParent:GetWidth(), UIParent:GetHeight()
  local cx, cy = W / 2, H / 2
  local n = 0
  local function line(vertical, pos, centre)
    n = n + 1
    local t = grid.lines[n]
    if not t then
      t = grid:CreateTexture(nil, "BACKGROUND")
      grid.lines[n] = t
    end
    t:ClearAllPoints()
    if centre then t:SetTexture(1, 0.25, 0.25, 0.7) else t:SetTexture(1, 1, 1, 0.13) end
    if vertical then
      t:SetPoint("TOP", grid, "TOPLEFT", pos, 0)
      t:SetPoint("BOTTOM", grid, "BOTTOMLEFT", pos, 0)
      t:SetWidth(1)
    else
      t:SetPoint("LEFT", grid, "BOTTOMLEFT", 0, pos)
      t:SetPoint("RIGHT", grid, "BOTTOMRIGHT", 0, pos)
      t:SetHeight(1)
    end
    t:Show()
  end
  for k = 0, math.ceil(cx / g) do
    line(true, cx + k * g, k == 0)
    if k > 0 then line(true, cx - k * g) end
  end
  for k = 0, math.ceil(cy / g) do
    line(false, cy + k * g, k == 0)
    if k > 0 then line(false, cy - k * g) end
  end
  for i = n + 1, #grid.lines do grid.lines[i]:Hide() end
  grid:Show()
end

------------------------------------------------------------------------
-- Group positions (relative to the nearest screen edge/corner so they
-- survive different aspect ratios)
------------------------------------------------------------------------

local function ApplyPos(key)
  local f, p = frames[key], db.pos[key]
  if not f or not p then return end
  local sc = f:GetScale()
  f:ClearAllPoints()
  f:SetPoint("CENTER", UIParent, p[1], p[2] / sc, p[3] / sc)
end

local function SavePos(key, snap)
  local f = frames[key]
  local cx, cy = AbsCenter(f)
  if not cx then return end
  if snap then cx, cy = SnapPoint(cx, cy, nil, true) end
  local W, H = UIParent:GetWidth(), UIParent:GetHeight()
  local h = (cx < W / 3 and "LEFT") or (cx > W * 2 / 3 and "RIGHT") or ""
  local v = (cy < H / 3 and "BOTTOM") or (cy > H * 2 / 3 and "TOP") or ""
  local point = v .. h
  if point == "" then point = "CENTER" end
  local ax = (h == "LEFT" and 0) or (h == "RIGHT" and W) or W / 2
  local ay = (v == "BOTTOM" and 0) or (v == "TOP" and H) or H / 2
  db.pos[key] = { point, cx - ax, cy - ay }
end

------------------------------------------------------------------------
-- Movers
------------------------------------------------------------------------

local movers, allButtons = {}, {}
local totem = { calls = {}, all = {} }

local function MoverBox(parent, r, g, b, text)
  local m = CreateFrame("Frame", nil, parent)
  m:SetFrameStrata("DIALOG")
  m:EnableMouse(true)
  m:RegisterForDrag("LeftButton")
  local tex = m:CreateTexture(nil, "BACKGROUND")
  tex:SetAllPoints()
  tex:SetTexture(r, g, b, 0.5)
  local fs = m:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  fs:SetPoint("CENTER")
  fs:SetText(text)
  m.text = fs
  m:Hide()
  return m
end

-- Group mover (green)
local function MakeMover(frame, key, text, handleAbove)
  frame:SetMovable(true)
  frame:SetClampedToScreen(true)
  local m = MoverBox(frame, 0, 0.8, 0.2, text)
  if handleAbove then
    Size(m, 80, 20)
    m:SetPoint("BOTTOM", frame, "TOP", 0, 4)
  else
    m:SetAllPoints(frame)
  end
  m:SetScript("OnDragStart", function() frame:StartMoving() end)
  m:SetScript("OnDragStop", function()
    frame:StopMovingOrSizing()
    frame:SetUserPlaced(false)
    SavePos(key, true)
    ApplyPos(key)
  end)
  movers[#movers + 1] = m
end

-- Per-button mover (blue)
local function MakeChildMover(btn, groupKey, store, idx, layoutFn, text)
  btn:SetMovable(true)
  local m = MoverBox(btn, 0.1, 0.45, 1, text)
  m:SetAllPoints(btn)
  m:SetScript("OnDragStart", function() btn:StartMoving() end)
  m:SetScript("OnDragStop", function()
    btn:StopMovingOrSizing()
    btn:SetUserPlaced(false)
    local bx, by = AbsCenter(btn)
    local gx, gy = AbsCenter(frames[groupKey])
    if bx and gx then
      bx, by = SnapPoint(bx, by, btn)
      local gs = UIScaleOf(frames[groupKey])
      local s = (groupKey == "k") and (db.spread or 1) or 1
      db[store][idx] = { (bx - gx) / gs / s, (by - gy) / gs / s }
    end
    layoutFn()
  end)
  movers[#movers + 1] = m
  return m
end

------------------------------------------------------------------------
-- Action buttons
------------------------------------------------------------------------

local function NewActionButton(name, parent)
  local b = CreateFrame("CheckButton", name, parent, "ActionBarButtonTemplate")
  b:SetAttribute("type", "action")
  b:SetAttribute("checkselfcast", true)
  b:SetAttribute("checkfocuscast", true)
  b:SetAttribute("showgrid", 1)        -- keep empty slots visible
  b:SetAttribute("statehidden", true)  -- stop the template calling Show()/Hide()
  b:RegisterForClicks("AnyUp")
  b:RegisterForDrag()
  b:Show()
  allButtons[#allButtons + 1] = b
  return b
end

local function RefreshButton(b)
  if ActionButton_UpdateAction then
    ActionButton_UpdateAction(b)
  else
    b.action = ActionButton_CalculateAction(b)
  end
  ActionButton_Update(b)
  if ActionButton_UpdateHotkeys then ActionButton_UpdateHotkeys(b, b.buttonType) end
end

-- Point a button at any action slot via page + id, like Blizzard's bars,
-- so it shows the hotkey of the matching Blizzard bar button.
local function SetButtonSlot(b, slot)
  local page, id = SlotToPage(slot)
  b:SetID(id)
  b:SetAttribute("actionpage", page)
  b.buttonType = PAGE_BIND[page] or "TOUCHHUDNOBIND"
end

local function NewStanceButton(name, parent)
  local b = CreateFrame("CheckButton", name, parent, "SecureActionButtonTemplate, ActionButtonTemplate")
  b:SetAttribute("type", "spell")
  b:RegisterForClicks("AnyUp")
  b.icon = _G[name .. "Icon"]
  b.cooldown = _G[name .. "Cooldown"]
  b:SetScript("PostClick", function() UpdateStanceButtons() end)
  return b
end

------------------------------------------------------------------------
-- K1..K12 cluster
------------------------------------------------------------------------

local function LayoutCluster()
  local f, s = frames.k, db.spread or 1
  for i, b in ipairs(kButtons) do
    local p = db.kpos[i] or K_LAYOUT[i]
    b:ClearAllPoints()
    b:SetPoint("CENTER", f, "CENTER", p[1] * s, p[2] * s)
  end
end

local function ApplyCluster()
  local any = false
  for i, b in ipairs(kButtons) do
    if db.kEnabled[i] then
      b:SetParent(frames.k)
      any = true
    else
      b:SetParent(hider)
    end
  end
  if any then frames.k:Show() else frames.k:Hide() end
  LayoutCluster()
end

local function BuildCluster()
  local f = CreateFrame("Frame", "TouchHUDCluster", UIParent)
  Size(f, 64, 64)
  frames.k = f

  local header = CreateFrame("Frame", "TouchHUDPager", UIParent, "SecureHandlerStateTemplate")
  for i = 1, NUM_K do
    local b = NewActionButton("TouchHUDK" .. i, f)
    b:SetID(i)   -- slot i of the current page, hotkey = binding of ACTIONBUTTONi
    SetRef(header, "k" .. i, b)
    kButtons[i] = b
  end

  header:SetAttribute("_onstate-page", [[
    local page = tonumber(newstate)
    for i = 1, 12 do
      self:GetFrameRef("k" .. i):SetAttribute("actionpage", page)
    end
  ]])
  header:HookScript("OnAttributeChanged", function(_, name)
    if name == "state-page" then
      for i = 1, NUM_K do RefreshButton(kButtons[i]) end
    end
  end)
  RegisterStateDriver(header, "page", PAGE_DRIVER)

  for i = 1, NUM_K do RefreshButton(kButtons[i]) end
  MakeMover(f, "k", "JOYSTICK\nCENTRE")
  for i = 1, NUM_K do
    MakeChildMover(kButtons[i], "k", "kpos", i, LayoutCluster, "K" .. TH.KEY_NAMES[i])
  end
end

------------------------------------------------------------------------
-- Flyouts (expandable buttons)
------------------------------------------------------------------------

local EXP_SNIPPET = [[
  local fly = self:GetFrameRef("fly")
  if fly:GetAttribute("alwaysopen") then return end
  if fly:IsShown() then
    fly:Hide()
  else
    if self:GetAttribute("exclusive") then
      for i = 1, 5 do
        local other = self:GetFrameRef("other" .. i)
        if other and not other:GetAttribute("alwaysopen") then other:Hide() end
      end
    end
    fly:Show()
  end
]]

function UpdateExpBorders()
  for i, e in ipairs(expButtons) do
    SetOpen(e, flyouts[i]:IsShown())
  end
end

local function ActiveFormTexture()
  local n = GetNumShapeshiftForms() or 0
  for j = 1, n do
    local tex, _, active = GetShapeshiftFormInfo(j)
    if active then return tex end
  end
  if n > 0 then return (GetShapeshiftFormInfo(1)) end
end

function UpdateExpIcons()
  if not db then return end
  for i, e in ipairs(expButtons) do
    local cfg, tex = db.flyouts[i], nil
    if cfg.source == "stance" then
      tex = ActiveFormTexture()
    else
      local slots = FlyoutSlots(i)
      for j = 1, cfg.count do
        tex = GetActionTexture(slots[j])
        if tex then break end
      end
    end
    e.icon:SetTexture(tex or QUESTION)
  end
end

function UpdateStanceButtons()
  for _, fly in ipairs(flyouts) do
    if fly.source == "stance" and fly.active then
      for _, b in ipairs(fly.active) do
        local tex, _, active, castable = GetShapeshiftFormInfo(b.formIndex)
        if tex then
          b.icon:SetTexture(tex)
          b:SetChecked(active and true or false)
          if castable then b.icon:SetVertexColor(1, 1, 1) else b.icon:SetVertexColor(0.4, 0.4, 0.4) end
          local s, d, en = GetShapeshiftFormCooldown(b.formIndex)
          if s and b.cooldown then CooldownFrame_SetTimer(b.cooldown, s, d, en) end
        end
      end
    end
  end
  UpdateExpIcons()
end

local function GetStanceButtons(fly)
  if not fly.stanceBtns then
    fly.stanceBtns = {}
    for j = 1, MAX_STANCES do
      fly.stanceBtns[j] = NewStanceButton(fly.flyName .. "Stance" .. j, hider)
    end
  end
  return fly.stanceBtns
end

local function LayoutExpanders()
  local f = frames.exp
  for i, e in ipairs(expButtons) do
    local p = db.epos[i] or EXP_LAYOUT[i]
    e:ClearAllPoints()
    e:SetPoint("CENTER", f, "CENTER", p[1], p[2])
  end
end

-- An always-open flyout can hide its expander (shown again in Move mode).
local function ApplyExpanderLook(i)
  local cfg, e = db.flyouts[i], expButtons[i]
  if cfg.alwaysOpen and cfg.hideExpander and TH.mode ~= "move" then
    e:SetAlpha(0)
    e:EnableMouse(false)
  else
    e:SetAlpha(1)
    e:EnableMouse(true)
  end
end

local function ApplyFlyout(i)
  local cfg, e, fly = db.flyouts[i], expButtons[i], flyouts[i]
  local nForms = GetNumShapeshiftForms() or 0
  local useStance = (cfg.source == "stance")

  for _, b in ipairs(fly.actionBtns) do b:SetParent(hider) end
  if fly.stanceBtns then
    for _, b in ipairs(fly.stanceBtns) do b:SetParent(hider) end
  end

  local list = {}
  fly.active, fly.source = list, cfg.source
  fly:SetAttribute("alwaysopen", cfg.alwaysOpen and true or false)

  if not cfg.enabled or (useStance and nForms == 0) then
    fly:Hide()
    e:Hide()
    return
  end

  if useStance then
    local sb = GetStanceButtons(fly)
    for j = 1, math.min(nForms, MAX_STANCES) do
      local _, name = GetShapeshiftFormInfo(j)
      if name then
        local b = sb[j]
        b.formIndex = j
        b:SetAttribute("spell", name)
        b:SetParent(fly)
        list[#list + 1] = b
      end
    end
  else
    local slots = FlyoutSlots(i)
    for j = 1, cfg.count do
      local b = fly.actionBtns[j]
      SetButtonSlot(b, slots[j])
      b:SetParent(fly)
      RefreshButton(b)
      list[#list + 1] = b
    end
  end

  e.label:SetText(cfg.label or "")
  e:SetAttribute("exclusive", db.exclusive and true or false)
  e:Show()

  local d = FLY_DIR[cfg.dir] or FLY_DIR.LEFT
  for j, b in ipairs(list) do
    b:ClearAllPoints()
    if j == 1 then
      b:SetPoint(d[1], e, d[2], d[3], d[4])
    else
      b:SetPoint(d[1], list[j - 1], d[2], d[5], d[6])
    end
  end
end

local function BuildExpanders()
  local f = CreateFrame("Frame", "TouchHUDExpanders", UIParent)
  Size(f, 44, 3 * 44 + 2 * 6)
  frames.exp = f

  for i = 1, NUM_FLYOUTS do
    local e = CreateFrame("Button", "TouchHUDExp" .. i, f, "SecureHandlerClickTemplate")
    Size(e, 44, 44)
    StyleBox(e)
    e:RegisterForClicks("AnyUp")
    e:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")

    local icon = e:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 5, -5)
    icon:SetPoint("BOTTOMRIGHT", -5, 5)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    e.icon = icon

    local label = e:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("BOTTOM", e, "BOTTOM", 0, 4)
    e.label = label

    e:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_LEFT")
      GameTooltip:SetText((db.flyouts[i].label ~= "" and db.flyouts[i].label) or ("Flyout " .. i))
      GameTooltip:AddLine("Click to open / close", 1, 1, 1)
      GameTooltip:Show()
    end)
    e:SetScript("OnLeave", function() GameTooltip:Hide() end)

    local fly = CreateFrame("Frame", "TouchHUDFly" .. i, f, "SecureFrameTemplate")
    Size(fly, 1, 1)
    fly:SetPoint("CENTER", e, "CENTER")
    fly.flyName = "TouchHUDFly" .. i
    fly.actionBtns = {}
    for j = 1, MAX_FLY_ACTIONS do
      fly.actionBtns[j] = NewActionButton("TouchHUDFly" .. i .. "Btn" .. j, hider)
    end
    fly:HookScript("OnShow", UpdateExpBorders)
    fly:HookScript("OnHide", UpdateExpBorders)

    SetRef(e, "fly", fly)
    e:SetAttribute("_onclick", EXP_SNIPPET)
    expButtons[i], flyouts[i] = e, fly
  end

  for i = 1, NUM_FLYOUTS do
    for j = 1, NUM_FLYOUTS do
      if i ~= j then SetRef(expButtons[i], "other" .. j, flyouts[j]) end
    end
    flyouts[i]:Hide()
  end

  MakeMover(f, "exp", "MOVE ALL", true)
  for i = 1, NUM_FLYOUTS do
    MakeChildMover(expButtons[i], "exp", "epos", i, LayoutExpanders, "E" .. i)
  end
end

------------------------------------------------------------------------
-- Extra bar (buttons on a Blizzard bar's slots + its key bindings)
------------------------------------------------------------------------

local EXTRA_STEP = 42

local function LayoutExtra()
  local f, cfg = frames.extra, db.extra
  local n = cfg.count
  local horiz = (cfg.row ~= "VERTICAL")
  for i, b in ipairs(xButtons) do
    local p = db.xpos[i]
    local dx, dy
    if p then
      dx, dy = p[1], p[2]
    else
      local o = (i - 1 - (n - 1) / 2) * EXTRA_STEP
      if horiz then dx, dy = o, 0 else dx, dy = 0, -o end
    end
    b:ClearAllPoints()
    b:SetPoint("CENTER", f, "CENTER", dx, dy)
  end
  if horiz then Size(f, n * EXTRA_STEP - 6, 36) else Size(f, 36, n * EXTRA_STEP - 6) end
end

local function ApplyExtra()
  local f, cfg = frames.extra, db.extra
  local bar = EXTRA_BAR
  for i, b in ipairs(xButtons) do
    b:SetID(i)
    b:SetAttribute("actionpage", bar.page)
    b.buttonType = bar.bind
    if cfg.enabled and i <= cfg.count and cfg.xEnabled[i] ~= false then
      b:SetParent(f)
    else
      b:SetParent(hider)
    end
    RefreshButton(b)
    local label = cfg.labels[i] or ""
    b.thLabel:SetText(label)
    if b.macroName then b.macroName:SetAlpha(label == "" and 1 or 0) end
  end
  if cfg.enabled then f:Show() else f:Hide() end
  LayoutExtra()
end

local function BuildExtra()
  local f = CreateFrame("Frame", "TouchHUDExtraBar", UIParent)
  Size(f, 300, 36)
  frames.extra = f
  for i = 1, MAX_EXTRA do
    local b = NewActionButton("TouchHUDX" .. i, f)
    local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("BOTTOMLEFT", 1, 2)
    fs:SetPoint("BOTTOMRIGHT", -1, 2)
    if STANDARD_TEXT_FONT then fs:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE") end
    b.thLabel = fs
    b.macroName = _G["TouchHUDX" .. i .. "Name"]
    xButtons[i] = b
  end
  MakeMover(f, "extra", "EXTRA BAR", true)
  for i = 1, MAX_EXTRA do
    MakeChildMover(xButtons[i], "extra", "xpos", i, LayoutExtra, "X" .. i)
  end
end

------------------------------------------------------------------------
-- Key bindings: keys bound to ACTIONBUTTON1-12 press K1-K12, keys bound to
-- the extra bar's Blizzard bar press X1-X12 (so they light up / page).
------------------------------------------------------------------------

local lastBindSig

function ApplyBindings()
  if not db then return end
  if InCombatLockdown() then TH.pendingBind = true return end
  TH.pendingBind = nil
  local pairsList = {}
  if db.routeBindings then
    for i = 1, NUM_K do
      if db.kEnabled[i] then
        for _, key in ipairs({ GetBindingKey("ACTIONBUTTON" .. i) }) do
          pairsList[#pairsList + 1] = { key, "TouchHUDK" .. i }
        end
      end
    end
    local x = db.extra
    if x.enabled then
      local bar = EXTRA_BAR
      for i = 1, x.count do
        if x.xEnabled[i] ~= false then
          for _, key in ipairs({ GetBindingKey(bar.bind .. i) }) do
            pairsList[#pairsList + 1] = { key, "TouchHUDX" .. i }
          end
        end
      end
    end
  end
  local sigParts = {}
  for _, p in ipairs(pairsList) do sigParts[#sigParts + 1] = p[1] .. ">" .. p[2] end
  local sig = table.concat(sigParts, ",")
  if sig == lastBindSig then return end
  lastBindSig = sig
  ClearOverrideBindings(core)
  for _, p in ipairs(pairsList) do
    SetOverrideBindingClick(core, false, p[1], p[2])
  end
end

------------------------------------------------------------------------
-- Menu drawer (Blizzard's own micro menu + bag buttons)
------------------------------------------------------------------------

local function LayoutDrawer()
  local drawer = TH.drawer
  if not drawer then return end
  local x = 6
  for _, n in ipairs(MICRO_BUTTONS) do
    local b = _G[n]
    if b then
      b:SetParent(drawer)
      b:ClearAllPoints()
      b:SetPoint("BOTTOMLEFT", drawer, "BOTTOMLEFT", x, 4)
      x = x + b:GetWidth() - 3
    end
  end
  x = x + 10
  for _, n in ipairs(BAG_BUTTONS) do
    local b = _G[n]
    if b then
      b:SetParent(drawer)
      b:ClearAllPoints()
      b:SetPoint("LEFT", drawer, "LEFT", x, 0)
      x = x + b:GetWidth() + 2
    end
  end
  x = x + 8
  local setup = TH.drawerSetup
  setup:ClearAllPoints()
  setup:SetPoint("LEFT", drawer, "LEFT", x, 0)
  x = x + setup:GetWidth()
  drawer:SetWidth(x + 6)
end

local function ApplyMenu()
  local f, drawer = frames.menu, TH.drawer
  if db.menu.enabled then f:Show() else f:Hide() end
  local a = DRAWER_DIR[db.menu.dir] or DRAWER_DIR.RIGHT
  drawer:ClearAllPoints()
  drawer:SetPoint(a[1], f, a[2], a[3], a[4])
  LayoutDrawer()
end

local function BuildMenu()
  local f = CreateFrame("Frame", "TouchHUDMenu", UIParent)
  Size(f, 52, 40)
  frames.menu = f

  local toggle = TextButton("TouchHUDMenuToggle", f, 52, 40, "MENU")
  toggle:SetAllPoints(f)

  local drawer = CreateFrame("Frame", "TouchHUDDrawer", f)
  drawer:SetHeight(46)
  drawer:SetWidth(100)
  drawer:SetClampedToScreen(true)
  StyleBox(drawer)
  drawer:Hide()
  TH.drawer = drawer

  local setup = TextButton("TouchHUDDrawerSetup", drawer, 70, 36, "Setup")
  setup:SetScript("OnClick", function()
    if TH.OpenConfig then TH.OpenConfig() end
  end)
  TH.drawerSetup = setup

  toggle:SetScript("OnClick", function()
    if drawer:IsShown() then drawer:Hide() else drawer:Show() end
  end)
  drawer:SetScript("OnShow", function() SetOpen(toggle, true) end)
  drawer:SetScript("OnHide", function() SetOpen(toggle, false) end)

  if MoveMicroButtons then hooksecurefunc("MoveMicroButtons", LayoutDrawer) end
  if VehicleMenuBar_MoveMicroButtons then hooksecurefunc("VehicleMenuBar_MoveMicroButtons", LayoutDrawer) end

  MakeMover(f, "menu", "MENU")
end

------------------------------------------------------------------------
-- ESC / ENTER pads
------------------------------------------------------------------------

local function ActiveEditBox()
  local eb = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
  if not eb and ChatFrameEditBox and ChatFrameEditBox:IsShown() then eb = ChatFrameEditBox end
  return eb
end

local function DoEscape()
  local eb = ActiveEditBox()
  if eb then
    if ChatEdit_OnEscapePressed then ChatEdit_OnEscapePressed(eb) else eb:Hide() end
    return
  end
  if StaticPopup_EscapePressed and StaticPopup_EscapePressed() then return end
  if GameMenuFrame:IsShown() then
    PlaySound("igMainMenuQuit")
    HideUIPanel(GameMenuFrame)
    return
  end
  if CloseMenus and CloseMenus() then return end
  if CloseAllWindows and CloseAllWindows() then return end
  PlaySound("igMainMenuOpen")
  ShowUIPanel(GameMenuFrame)
end

local function DoEnter()
  local eb = ActiveEditBox()
  if eb then
    if ChatEdit_OnEnterPressed then ChatEdit_OnEnterPressed(eb) else ChatEdit_SendText(eb, 1) end
  else
    ChatFrame_OpenChat("")
  end
end

local function BuildKeys()
  local f = CreateFrame("Frame", "TouchHUDKeys", UIParent)
  Size(f, 80, 84)
  frames.keys = f

  local esc = TextButton("TouchHUDEsc", f, 80, 38, "ESC")
  esc:SetPoint("TOP", f, "TOP")
  esc:SetScript("OnClick", DoEscape)

  local ent = TextButton("TouchHUDEnter", f, 80, 38, "ENTER")
  ent:SetPoint("BOTTOM", f, "BOTTOM")
  ent:SetScript("OnClick", DoEnter)

  MakeMover(f, "keys", "ESC / ENTER")
end

------------------------------------------------------------------------
-- Pet bar
------------------------------------------------------------------------

local PET_SIZE, PET_GAP = 30, 6

local function LayoutPet()
  local f = frames.pet
  if not f then return end
  local cols = db.pet.cols
  for i = 1, 10 do
    local b = _G["PetActionButton" .. i]
    if b then
      local c, r = (i - 1) % cols, math.floor((i - 1) / cols)
      b:ClearAllPoints()
      b:SetPoint("TOPLEFT", f, "TOPLEFT", c * (PET_SIZE + PET_GAP), -r * (PET_SIZE + PET_GAP))
    end
  end
  local rows = math.ceil(10 / cols)
  Size(f, cols * (PET_SIZE + PET_GAP) - PET_GAP, rows * (PET_SIZE + PET_GAP) - PET_GAP)
end

local function ApplyPetVisibility()
  local f = frames.pet
  if not f then return end
  if TH.mode == "move" then
    UnregisterStateDriver(f, "visibility")
    f:Show()
  else
    RegisterStateDriver(f, "visibility", "[bonusbar:5]hide;[pet]show;hide")
  end
end

local function BuildPet()
  local f = CreateFrame("Frame", "TouchHUDPetBar", UIParent, "SecureHandlerStateTemplate")
  frames.pet = f
  for i = 1, 10 do
    local b = _G["PetActionButton" .. i]
    if b then b:SetParent(f) end
  end
  MakeMover(f, "pet", "PET BAR")
end

------------------------------------------------------------------------
-- Totems (Shaman)
------------------------------------------------------------------------

local function TotemAction(page, element) return 132 + (page - 1) * 4 + element end

function UpdateTotemSlots()
  if not frames.totem then return end
  for _, c in ipairs(totem.calls) do
    for _, s in ipairs(c.fly.slots) do
      local tex = GetActionTexture(s.action)
      s.icon:SetTexture(tex or QUESTION)
      s.icon:SetAlpha(tex and 1 or 0.35)
    end
  end
end

function UpdateTotemCooldowns()
  if not frames.totem then return end
  for _, b in ipairs(totem.all) do
    if b.spellName and b:IsShown() then
      local s, d, en = GetSpellCooldown(b.spellName)
      if s then CooldownFrame_SetTimer(b.cooldown, s, d, en) end
      local usable, noMana = IsUsableSpell(b.spellName)
      if usable then
        b.icon:SetVertexColor(1, 1, 1)
      elseif noMana then
        b.icon:SetVertexColor(0.5, 0.5, 1)
      else
        b.icon:SetVertexColor(0.4, 0.4, 0.4)
      end
    end
  end
end

local function Chooser_OnClick(self)
  if InCombatLockdown() then Print("can't change totems in combat.") return end
  local ok, err = pcall(SetMultiCastSpell, self.action, self.spellId)
  if not ok then Print("couldn't set that totem: " .. tostring(err)) end
  totem.chooser:Hide()
  UpdateTotemSlots()
end

local function OpenChooser(slot)
  local ch = totem.chooser
  if ch:IsShown() and ch.owner == slot then ch:Hide() return end
  if InCombatLockdown() then Print("can't change totems in combat.") return end
  if not GetMultiCastTotemSpells then return end

  local ids = { 0 }
  for _, id in ipairs({ GetMultiCastTotemSpells(slot.element) }) do ids[#ids + 1] = id end

  local current = GetActionTexture(slot.action)
  local d = FLY_DIR[db.totem.chooserDir] or FLY_DIR.RIGHT
  local prev
  for j, id in ipairs(ids) do
    local b = ch.buttons[j]
    if not b then
      b = IconButton(nil, ch, 40, false)
      b:SetScript("OnClick", Chooser_OnClick)
      ch.buttons[j] = b
    end
    local tex = (id == 0) and "Interface\\Buttons\\UI-GroupLoot-Pass-Up" or select(3, GetSpellInfo(id))
    b.spellId, b.action = id, slot.action
    b.icon:SetTexture(tex or QUESTION)
    SetOpen(b, (id ~= 0 and tex == current) or (id == 0 and not current))
    b:ClearAllPoints()
    if not prev then
      b:SetPoint(d[1], slot, d[2], d[3], d[4])
    else
      b:SetPoint(d[1], prev, d[2], d[5], d[6])
    end
    b:Show()
    prev = b
  end
  for j = #ids + 1, #ch.buttons do ch.buttons[j]:Hide() end
  ch.owner = slot
  ch:Show()
end

local function ToggleTotemFly(p)
  for q, c in ipairs(totem.calls) do
    if q == p then
      if c.fly:IsShown() then c.fly:Hide() else c.fly:Show() end
    else
      c.fly:Hide()
    end
  end
end

function LayoutTotems()
  local f = frames.totem
  if not f then return end
  local cfg = db.totem
  local horiz = (cfg.row ~= "VERTICAL")

  local list = {}
  for _, c in ipairs(totem.calls) do
    if c.spellName and GetSpellInfo(c.spellName) then
      list[#list + 1] = c
      c:Show()
    else
      c:Hide()
      c.fly:Hide()
    end
  end
  local r = totem.recall
  if r.spellName and GetSpellInfo(r.spellName) then
    list[#list + 1] = r
    r:Show()
  else
    r:Hide()
  end

  for k, b in ipairs(list) do
    b:ClearAllPoints()
    if horiz then
      b:SetPoint("LEFT", f, "LEFT", (k - 1) * 52, 0)
    else
      b:SetPoint("TOP", f, "TOP", 0, -(k - 1) * 52)
    end
  end
  local n = math.max(1, #list)
  if horiz then Size(f, n * 52 - 8, 44) else Size(f, 44, n * 52 - 8) end
  if #list == 0 then f:Hide() else f:Show() end

  local t = TAB_DIR[cfg.dir] or TAB_DIR.UP
  local d = FLY_DIR[cfg.dir] or FLY_DIR.UP
  for _, c in ipairs(totem.calls) do
    c.tab:ClearAllPoints()
    Size(c.tab, t[5], t[6])
    c.tab:SetPoint(t[1], c, t[2], t[3], t[4])
    if c:IsShown() then c.tab:Show() else c.tab:Hide() end
    for i, s in ipairs(c.fly.slots) do
      s:ClearAllPoints()
      if i == 1 then
        s:SetPoint(d[1], c.tab, d[2], d[5], d[6])
      else
        s:SetPoint(d[1], c.fly.slots[i - 1], d[2], d[5], d[6])
      end
    end
  end
  totem.chooser:Hide()
end

local function BuildTotems()
  local f = CreateFrame("Frame", "TouchHUDTotems", UIParent)
  Size(f, 200, 44)
  frames.totem = f

  for p = 1, 3 do
    local c = IconButton("TouchHUDTotemCall" .. p, f, 44, true)
    c:SetAttribute("type", "spell")
    c.spellName = GetSpellInfo(TOTEM_CALLS[p])
    if c.spellName then c:SetAttribute("spell", c.spellName) end
    c.icon:SetTexture(select(3, GetSpellInfo(TOTEM_CALLS[p])) or QUESTION)
    c.cooldown = CreateFrame("Cooldown", nil, c)
    c.cooldown:SetAllPoints(c.icon)

    local tab = TextButton(nil, f, 44, 18, "+")
    tab:SetScript("OnClick", function() ToggleTotemFly(p) end)
    c.tab = tab

    local fly = CreateFrame("Frame", nil, f)
    Size(fly, 1, 1)
    fly:SetPoint("CENTER", c, "CENTER")
    fly:Hide()
    fly.slots = {}
    for i = 1, 4 do
      local s = IconButton(nil, fly, 40, false)
      s.element = TOTEM_ORDER[i]
      -- multicast slots are stored Fire(1), Earth(2), Water(3), Air(4)
      s.action = TotemAction(p, s.element)
      s:SetBackdropBorderColor(unpack(ELEMENT_COLOR[s.element] or BORDER_IDLE))
      local fs = s:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      fs:SetPoint("BOTTOM", 0, 3)
      fs:SetText(ELEMENT_NAME[s.element] or "")
      s:SetScript("OnClick", OpenChooser)
      fly.slots[i] = s
    end
    fly:SetScript("OnShow", function() tab.text:SetText("-"); SetOpen(tab, true) end)
    fly:SetScript("OnHide", function()
      tab.text:SetText("+"); SetOpen(tab, false)
      if totem.chooser and totem.chooser.owner and totem.chooser.owner:GetParent() == fly then
        totem.chooser:Hide()
      end
    end)
    c.fly = fly
    totem.calls[p] = c
    totem.all[#totem.all + 1] = c
  end

  local r = IconButton("TouchHUDTotemRecall", f, 44, true)
  r:SetAttribute("type", "spell")
  r.spellName = GetSpellInfo(TOTEM_RECALL)
  if r.spellName then r:SetAttribute("spell", r.spellName) end
  r.icon:SetTexture(select(3, GetSpellInfo(TOTEM_RECALL)) or QUESTION)
  r.cooldown = CreateFrame("Cooldown", nil, r)
  r.cooldown:SetAllPoints(r.icon)
  totem.recall = r
  totem.all[#totem.all + 1] = r

  local ch = CreateFrame("Frame", "TouchHUDTotemChooser", f)
  Size(ch, 1, 1)
  ch:SetPoint("CENTER", f, "CENTER")
  ch:SetFrameLevel(f:GetFrameLevel() + 20)
  ch.buttons = {}
  ch:Hide()
  totem.chooser = ch

  MakeMover(f, "totem", "TOTEMS")
end

------------------------------------------------------------------------
-- Blizzard bars we replace or rescue
------------------------------------------------------------------------

local origParent = {}

local function Park(frameName, park)
  local fr = _G[frameName]
  if not fr then return end
  if origParent[frameName] == nil then origParent[frameName] = fr:GetParent() or UIParent end
  if park then
    fr:SetParent(hider)
  elseif db.hideMainBar and origParent[frameName] == MainMenuBar then
    fr:SetParent(UIParent)
  else
    fr:SetParent(origParent[frameName])
  end
end

local function StanceFlyoutActive()
  if (GetNumShapeshiftForms() or 0) == 0 then return false end
  return db.flyouts[STANCE_FLYOUT].enabled and true or false
end

TH.BLIZZ_BARS = {
  { key = "bottomLeft",  frame = "MultiBarBottomLeft",  name = "Bottom Left" },
  { key = "bottomRight", frame = "MultiBarBottomRight", name = "Bottom Right" },
  { key = "right",       frame = "MultiBarRight",       name = "Right" },
  { key = "right2",      frame = "MultiBarLeft",        name = "Right 2" },
}

local function ApplyBlizzardBars()
  for _, b in ipairs(TH.BLIZZ_BARS) do
    Park(b.frame, db.hideBars[b.key] and true or false)
  end
  Park("ShapeshiftBarFrame", StanceFlyoutActive())
  Park("PossessBarFrame", false)
  Park("PetActionBarFrame", frames.pet ~= nil)
  Park("MultiCastActionBarFrame", frames.totem ~= nil)
end

------------------------------------------------------------------------
-- Modes:  lock (play) / move (green = group, blue = single button) /
--         edit (assign / rearrange spells, all flyouts open)
------------------------------------------------------------------------

function SetMode(mode, quiet)
  if InCombatLockdown() then Print("can't do that in combat.") return end
  TH.mode = mode
  local moving, editing = (mode == "move"), (mode == "edit")
  for _, m in ipairs(movers) do
    if moving then m:Show() else m:Hide() end
  end
  for _, b in ipairs(allButtons) do
    if editing then b:RegisterForDrag("LeftButton", "RightButton") else b:RegisterForDrag() end
  end
  local open = (mode ~= "lock")
  for i, fly in ipairs(flyouts) do
    if expButtons[i]:IsShown() and (open or db.flyouts[i].alwaysOpen) then fly:Show() else fly:Hide() end
    ApplyExpanderLook(i)
  end
  if TH.drawer then
    if open then TH.drawer:Show() else TH.drawer:Hide() end
  end
  ApplyPetVisibility()
  UpdateGrid()
  if TH.doneBtn then
    if open then TH.doneBtn:Show() else TH.doneBtn:Hide() end
  end
  if quiet then return end
  if moving then
    Print("MOVE: green = move a group (put JOYSTICK CENTRE on GameHub's joystick), blue = move one button. Hold Shift while dropping to skip snapping. Tap DONE when finished.")
  elseif editing then
    Print("EDIT: drag spells/items/macros onto buttons, or drag them off / between buttons. Tap DONE when finished.")
  end
end
TH.SetMode = function(mode) SetMode(mode) end
TH.ToggleMove = function()
  if not db then return end
  SetMode(TH.mode == "move" and "lock" or "move")
end

------------------------------------------------------------------------
-- Apply every setting (out of combat)
------------------------------------------------------------------------

function ApplyAll()
  if not db then return end
  if InCombatLockdown() then TH.pending = true return end
  TH.pending = nil

  ApplyCluster()
  for i = 1, NUM_FLYOUTS do ApplyFlyout(i) end
  LayoutExpanders()
  UpdateStanceButtons()
  UpdateExpBorders()
  ApplyExtra()

  ApplyMenu()
  if db.keys.enabled then frames.keys:Show() else frames.keys:Hide() end

  if frames.pet then LayoutPet() end
  if frames.totem then
    LayoutTotems()
    UpdateTotemSlots()
    UpdateTotemCooldowns()
  end

  ApplyBlizzardBars()

  for key, f in pairs(frames) do
    f:SetScale(db.scale[key] or 1)
    ApplyPos(key)
  end

  ApplyBindings()
  SetMode(TH.mode or "lock", true)
end
TH.ApplyAll = function() ApplyAll() end

function TH.ResetButtons()
  if InCombatLockdown() then Print("can't do that in combat.") return end
  db.kpos, db.epos, db.xpos = {}, {}, {}
  ApplyAll()
  Print("button layout reset.")
end

------------------------------------------------------------------------
-- Moving spells from 2.0/2.1 flyout slots to the fixed slot map.
-- Only swaps slot contents (nothing is deleted). Per character, since
-- action bars are stored by the server per character.
------------------------------------------------------------------------

local function LegacyPairs()
  local list, usedFrom, usedTo = {}, {}, {}
  if not db or type(db.legacy) ~= "table" then return list end
  for n = 1, NUM_ACTION_FLYOUTS do
    local olds, news = db.legacy[n], FlyoutSlots(n)
    if type(olds) == "table" then
      for j, from in ipairs(olds) do
        local to = news[j]
        if type(from) == "number" and to and from >= 1 and from <= 120
           and not usedFrom[from] and not usedTo[to] then
          usedFrom[from], usedTo[to] = true, true
          list[#list + 1] = { from, to }
        end
      end
    end
  end
  return list
end

-- true when this character still has spells sitting in old flyout slots
function TH.LegacyPending()
  if TouchHUDCharDB and TouchHUDCharDB.legacyDone then return false end
  for _, p in ipairs(LegacyPairs()) do
    if p[1] ~= p[2] and HasAction(p[1]) then return true end
  end
  return false
end

function TH.LegacyText()
  local parts = {}
  for n = 1, NUM_ACTION_FLYOUTS do
    local l = db.legacy and db.legacy[n]
    if type(l) == "table" and #l > 0 then
      parts[#parts + 1] = "flyout " .. n .. ": old slots " .. l[1] .. "-" .. l[#l]
    end
  end
  return table.concat(parts, ", ")
end

local function SwapSlots(a, b)
  local ha, hb = HasAction(a), HasAction(b)
  if not ha and not hb then return end
  ClearCursor()
  if ha then
    PickupAction(a)
    PlaceAction(b)
    if hb then PlaceAction(a) end
  else
    PickupAction(b)
    PlaceAction(a)
  end
  ClearCursor()
end

function TH.MoveLegacySpells()
  if InCombatLockdown() then Print("can't move spells in combat.") return end
  local list = LegacyPairs()
  -- build the wanted end state: target slot <- original slot
  local want, froms, tos = {}, {}, {}
  for _, p in ipairs(list) do
    want[p[2]] = p[1]
    froms[p[1]], tos[p[2]] = true, true
  end
  -- slots that are emptied receive whatever was displaced from the targets
  local vacated, displaced = {}, {}
  for s in pairs(froms) do if not tos[s] then vacated[#vacated + 1] = s end end
  for s in pairs(tos) do if not froms[s] then displaced[#displaced + 1] = s end end
  table.sort(vacated)
  table.sort(displaced)
  for j = 1, #vacated do want[vacated[j]] = displaced[j] end

  -- carry it out with swaps (selection: put the right content in each slot)
  local at, pos, targets = {}, {}, {}
  for s in pairs(want) do
    at[s], pos[s] = s, s
    targets[#targets + 1] = s
  end
  table.sort(targets)
  local swaps = 0
  for _, t in ipairs(targets) do
    local src = want[t]
    local cur = pos[src]
    if cur ~= t then
      SwapSlots(t, cur)
      local a, b = at[t], at[cur]
      at[t], at[cur] = b, a
      pos[b], pos[a] = t, cur
      swaps = swaps + 1
    end
  end
  TouchHUDCharDB = TouchHUDCharDB or {}
  TouchHUDCharDB.legacyDone = true
  ApplyAll()
  Print("moved your flyout spells to their new slots (" .. swaps .. " swaps). Nothing was deleted.")
end

function TH.SkipLegacy()
  TouchHUDCharDB = TouchHUDCharDB or {}
  TouchHUDCharDB.legacyDone = true
end

------------------------------------------------------------------------
-- Layouts (profiles)
------------------------------------------------------------------------

function TH.ProfileNames()
  local names = {}
  for name in pairs(TouchHUDDB.profiles) do names[#names + 1] = name end
  table.sort(names)
  return names
end

function TH.CurrentProfile() return TouchHUDDB.current end

local function CleanName(name)
  name = (name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name == "" or #name > 20 then return nil end
  return name
end
TH.CleanName = CleanName

-- copy the active layout under a new name and switch to it (no reload needed)
function TH.SaveAsProfile(name)
  name = CleanName(name)
  if not name then return false, "Pick a name of 1-20 letters." end
  if TouchHUDDB.profiles[name] then return false, "A layout called \"" .. name .. "\" already exists." end
  local copy = DeepCopy(db)
  TouchHUDDB.profiles[name] = copy
  TouchHUDDB.current = name
  db = copy
  TH.db = db
  ApplyAll()
  return true
end

function TH.SwitchProfile(name)
  if not TouchHUDDB.profiles[name] then return end
  TouchHUDDB.current = name
  ReloadUI()
end

function TH.DeleteCurrentProfile()
  local names = TH.ProfileNames()
  if #names < 2 then return end
  local cur = TouchHUDDB.current
  TouchHUDDB.profiles[cur] = nil
  for _, n in ipairs(names) do
    if n ~= cur then TouchHUDDB.current = n break end
  end
  ReloadUI()
end

function TH.ReplaceCurrentProfile(t)
  TouchHUDDB.profiles[TouchHUDDB.current] = t
  ReloadUI()
end

------------------------------------------------------------------------
-- Slash commands
------------------------------------------------------------------------

local function Help()
  Print("/thud  - open the settings window")
  Print("/thud move  - reposition groups (green) and single buttons (blue)")
  Print("/thud edit  - assign/rearrange spells, all flyouts open")
  Print("/thud lock  - back to normal play")
  Print("/thud layout <name>  - switch to a saved layout")
  Print("/thud resetbuttons  - button positions back to default")
  Print("/thud reset  - reset the current layout (reloads UI)")
end

SLASH_TOUCHHUD1 = "/thud"
SLASH_TOUCHHUD2 = "/touchhud"
SlashCmdList.TOUCHHUD = function(msg)
  if not db then return end
  local cmd, rest = (msg or ""):match("^(%S*)%s*(.-)%s*$")
  cmd = (cmd or ""):lower()
  if cmd == "" or cmd == "config" or cmd == "options" then
    if TH.OpenConfig then TH.OpenConfig() end
  elseif cmd == "move" or cmd == "unlock" then
    SetMode("move")
  elseif cmd == "edit" then
    SetMode("edit")
  elseif cmd == "lock" then
    SetMode("lock")
  elseif cmd == "layout" or cmd == "profile" then
    if TouchHUDDB.profiles[rest] then
      TH.SwitchProfile(rest)
    else
      Print("layouts: " .. table.concat(TH.ProfileNames(), ", "))
    end
  elseif cmd == "resetbuttons" then
    TH.ResetButtons()
  elseif cmd == "reset" then
    TouchHUDDB.profiles[TouchHUDDB.current] = nil
    ReloadUI()
  else
    Help()
  end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------

local function Init()
  TouchHUDDB = PrepareRoot(TouchHUDDB)
  if type(TouchHUDCharDB) ~= "table" then TouchHUDCharDB = {} end
  db = TouchHUDDB.profiles[TouchHUDDB.current]
  TH.db = db
  local _, class = UnitClass("player")
  TH.playerClass = class

  if db.hideMainBar then MainMenuBar:SetParent(hider) end

  BuildCluster()
  BuildExpanders()
  BuildExtra()
  BuildMenu()
  BuildKeys()
  if db.pet.enabled then BuildPet() end
  if class == "SHAMAN" and db.totem.enabled then BuildTotems() end

  local done = TextButton("TouchHUDDone", UIParent, 170, 44, "DONE  (lock)")
  done:SetPoint("TOP", UIParent, "TOP", 0, -90)
  done:SetFrameStrata("FULLSCREEN_DIALOG")
  done:SetScript("OnClick", function() SetMode("lock") end)
  done:Hide()
  TH.doneBtn = done

  TH.mode = "lock"
  TH.ready = true
  ApplyAll()

  for _, ev in ipairs({
    "ACTIONBAR_SLOT_CHANGED", "PLAYER_ENTERING_WORLD", "UPDATE_BINDINGS",
    "UPDATE_SHAPESHIFT_FORMS", "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_USABLE",
    "UPDATE_SHAPESHIFT_COOLDOWN", "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE",
    "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB",
  }) do
    core:RegisterEvent(ev)
  end
end

core:RegisterEvent("PLAYER_LOGIN")
core:RegisterEvent("PLAYER_REGEN_ENABLED")
core:SetScript("OnEvent", function(self, event, arg1)
  if event == "PLAYER_LOGIN" then
    if not InCombatLockdown() then Init() end
    return
  elseif event == "PLAYER_REGEN_ENABLED" then
    if not TH.ready then
      Init()
    else
      if TH.pending then ApplyAll() end
      if TH.pendingBind then ApplyBindings() end
    end
    return
  end
  if not TH.ready then return end

  if event == "ACTIONBAR_SLOT_CHANGED" then
    UpdateExpIcons()
    if not arg1 or (arg1 >= 133 and arg1 <= 144) then UpdateTotemSlots() end
  elseif event == "UPDATE_BINDINGS" then
    ApplyBindings()
  elseif event == "PLAYER_ENTERING_WORLD" then
    if not TH.legacyNoticed then
      TH.legacyNoticed = true
      if TH.LegacyPending() then
        Print("flyouts now use fixed slots. Open /thud > Flyouts to move this character's old flyout spells (one tap).")
      end
    end
    UpdateStanceButtons()
    UpdateTotemSlots()
    UpdateTotemCooldowns()
  elseif event == "UPDATE_SHAPESHIFT_FORMS" or event == "SPELLS_CHANGED" or event == "LEARNED_SPELL_IN_TAB" then
    if InCombatLockdown() then
      TH.pending = true
    elseif event == "UPDATE_SHAPESHIFT_FORMS" then
      ApplyAll()
    else
      LayoutTotems()
      UpdateTotemCooldowns()
    end
  elseif event == "SPELL_UPDATE_COOLDOWN" or event == "SPELL_UPDATE_USABLE" then
    UpdateTotemCooldowns()
  else
    UpdateStanceButtons()
  end
end)

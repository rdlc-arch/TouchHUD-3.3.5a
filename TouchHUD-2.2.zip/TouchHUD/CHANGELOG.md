# Changelog

## 2.2
- Fixed slot map: every button owns its own Blizzard action slot (no overlaps), so spells
  are on the default bars even without the addon.
- Flyouts 1-4 use 8 fixed slots each, flyout 5 is the stance / form / aura bar.
- One-time "Move my old flyout spells" helper for 2.0 / 2.1 users (swaps only, deletes nothing).
- Option to hide Blizzard's Bottom Left, Bottom Right, Right and Right 2 bars.

## 2.1
- K1-K12 (whole number row), each one can be turned on/off.
- Flyouts can stay always open, optionally hiding their button.
- Extra bar (up to 12 buttons) using Blizzard bar key bindings, for mice with extra buttons.
- Move mode: grid overlay, snap to grid, line up with other buttons.
- Named layouts (e.g. PC / Touch).
- TouchHUD section in Key Bindings; flyout buttons show Blizzard bar hotkeys.

## 2.0
- Settings window, 5 configurable flyouts, stance/form/aura flyout.
- Shaman totem bar with nested totem picker.
- Own pet bar, menu drawer directions, enable/disable everything.
- Export / import layout strings.

## 1.x
- K1-K8 arc around a virtual joystick, 3 expandable flyouts, menu drawer, ESC / ENTER pads.
